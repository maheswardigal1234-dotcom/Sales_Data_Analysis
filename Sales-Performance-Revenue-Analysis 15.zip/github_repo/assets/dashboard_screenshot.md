# 📊 Power BI Dashboard — Visual Reference

## Dashboard Pages Overview

The Power BI dashboard is organised into 4 main pages. Below is a description
of each page's layout and content for reference when building in Power BI Desktop.

---

## Page 1: Overview

```
┌──────────────────────────────────────────────────────────────────┐
│  SALES PERFORMANCE DASHBOARD                          [Year ▼]   │
├──────────┬──────────┬──────────┬──────────┬─────────────────────┤
│ Total    │ Revenue  │   AOV    │  Txns    │                     │
│ Revenue  │ Growth   │          │  Volume  │  Revenue Trend      │
│ $7.1M    │ +11.1%   │  $422    │  16,825  │  (Line Chart)       │
│ ▲ YoY    │ ▲ YoY    │  ▲ YoY   │  ▲ YoY   │  Monthly 2024      │
├──────────┴──────────┴──────────┴──────────┼─────────────────────┤
│                                            │                     │
│   Target vs Actual (Gauge Charts)          │  Category Mix       │
│   Q1  Q2  Q3  Q4                           │  (Pie Chart)        │
│                                            │                     │
└────────────────────────────────────────────┴─────────────────────┘
```

**KPIs shown:** Total Revenue, Revenue Growth %, AOV, Transaction Volume, Target Achievement

---

## Page 2: Performance Analysis

```
┌──────────────────────────────────────────────────────────────────┐
│  PERFORMANCE ANALYSIS                     [Region ▼] [Quarter ▼] │
├─────────────────────────────────┬────────────────────────────────┤
│                                 │                                │
│   Revenue: 2023 vs 2024         │   Quarter-over-Quarter Growth  │
│   (Grouped Bar Chart)           │   (Line Chart with markers)    │
│   Q1  Q2  Q3  Q4               │   Q1→Q2→Q3→Q4                 │
│                                 │                                │
├─────────────────────────────────┼────────────────────────────────┤
│                                 │                                │
│   Target vs Actual              │   Revenue Contribution         │
│   (Stacked Bar: Actual/Target)  │   by Channel                   │
│   2022  2023  2024              │   (Horizontal Bar)             │
│                                 │                                │
└─────────────────────────────────┴────────────────────────────────┘
```

**KPIs shown:** YoY Trends, QoQ Growth, Target Achievement, Channel Contribution

---

## Page 3: Product Analysis

```
┌──────────────────────────────────────────────────────────────────┐
│  PRODUCT ANALYSIS                         [Category ▼] [Year ▼]  │
├─────────────────────────────────┬────────────────────────────────┤
│                                 │                                │
│   Top Categories by Revenue     │   YoY Growth Rate              │
│   (Ranked Horizontal Bar)       │   (Bar Chart: green/red)       │
│   1. Electronics                │   Electronics  +17.1%          │
│   2. Sports & Outdoors          │   Sports       +17.1%          │
│   3. Home & Garden              │   Home & Garden +13.9%         │
│   ...                           │   ...                          │
├─────────────────────────────────┼────────────────────────────────┤
│                                 │                                │
│   Profit Margin by Category     │   Category Classification      │
│   (Horizontal Bar)              │   (Matrix / Table)             │
│   Clothing    45%               │   ⭐ Star  📈 Growth           │
│   Health      42%               │   📊 Stable ⚠️ Watch           │
│   ...                           │                                │
└─────────────────────────────────┴────────────────────────────────┘
```

**KPIs shown:** Category Contribution %, Top Products, Profit Margin, Growth Classification

---

## Page 4: Regional Analysis

```
┌──────────────────────────────────────────────────────────────────┐
│  REGIONAL ANALYSIS                        [Region ▼] [Year ▼]    │
├─────────────────────────────────┬────────────────────────────────┤
│                                 │                                │
│   Revenue by Region             │   Regional Growth Rate         │
│   (Horizontal Bar)              │   (Bar Chart with status)      │
│   North   $1.8M  ✅             │   North    +12.3%  ✅          │
│   South   $1.5M  ✅             │   South     +8.7%  ✅          │
│   East    $1.4M  ✅             │   East      +5.2%  ✅          │
│   West    $1.0M  ⚠️             │   West     -4.1%   ⚠️          │
│   Central $0.8M  ⚠️             │   Central  -7.8%   ⚠️          │
├─────────────────────────────────┼────────────────────────────────┤
│                                 │                                │
│   At-Risk Region Detail         │   Top Category per Region      │
│   (Cards for West & Central)    │   (Matrix Table)               │
│   West: Retention ↓15%          │   North → Electronics          │
│   Central: Conv. Rate 2.1%      │   South → Home & Garden        │
│                                 │   ...                          │
└─────────────────────────────────┴────────────────────────────────┘
```

**KPIs shown:** Revenue per Region, Regional Growth, At-Risk Flags, Category Mix per Region

---

## Filters & Slicers (Global)

| Slicer | Location | Options |
|--------|----------|---------|
| Year | Top-right | 2022, 2023, 2024 |
| Quarter | Top-right | Q1, Q2, Q3, Q4 |
| Region | Top-right | North, South, East, West, Central |
| Category | Top-right | All 10 categories |

---

## Color Scheme

| Element | Color | Hex |
|---------|-------|-----|
| Primary (headers, titles) | Deep Blue | `#065A82` |
| Secondary (bars, charts) | Teal | `#1C7293` |
| Accent (highlights) | Mint | `#02C39A` |
| On Track | Green | `#10B981` |
| Warning / At Risk | Amber | `#F59E0B` |
| Danger / Decline | Red | `#EF4444` |
| Background | White | `#FFFFFF` |
| Card Background | Light Gray | `#F5F5F5` |
