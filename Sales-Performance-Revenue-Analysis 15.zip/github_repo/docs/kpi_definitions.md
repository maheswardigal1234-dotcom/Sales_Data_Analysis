# 📊 KPI Definitions

All KPIs tracked in the Power BI dashboard, with formulas and business context.

---

## Revenue KPIs

### 1. Total Revenue
- **Definition:** Sum of all `Total_Revenue` values in the selected period
- **Formula:** `SUM(sales_fact.total_revenue)`
- **Purpose:** Primary performance metric; measures overall sales output
- **DAX:** `Total Revenue = SUM(sales_fact[Total_Revenue])`

### 2. Revenue Growth Rate (YoY)
- **Definition:** Percentage change in total revenue compared to the same period last year
- **Formula:** `(Current Year Revenue − Prior Year Revenue) ÷ Prior Year Revenue × 100`
- **Purpose:** Measures year-over-year business momentum
- **DAX:** `YoY Growth = (CALCULATE(SUM(...), YEAR = 2024) - CALCULATE(SUM(...), YEAR = 2023)) / CALCULATE(SUM(...), YEAR = 2023)`

### 3. Target Achievement %
- **Definition:** Actual quarterly revenue as a percentage of the set quarterly target
- **Formula:** `Actual Revenue ÷ Quarterly Target × 100`
- **Purpose:** Measures how well the team is tracking against planned goals
- **Threshold:** ≥ 100% = On Target | 90–99% = Near Target | < 90% = Below Target

---

## Efficiency KPIs

### 4. Average Order Value (AOV)
- **Definition:** Mean revenue per transaction
- **Formula:** `SUM(Total_Revenue) ÷ COUNT(Transaction_ID)`
- **Purpose:** Indicates customer spend per visit; higher AOV = more revenue per transaction
- **DAX:** `AOV = AVERAGE(sales_fact[Total_Revenue])`

### 5. Transaction Volume
- **Definition:** Total number of transactions in the selected period
- **Formula:** `COUNT(Transaction_ID)`
- **Purpose:** Measures sales activity and demand volume
- **DAX:** `Transactions = COUNTA(sales_fact[Transaction_ID])`

---

## Regional KPIs

### 6. Revenue per Region
- **Definition:** Total revenue broken down by geographic region
- **Formula:** `SUM(Total_Revenue) GROUP BY Region`
- **Purpose:** Identifies top/bottom-performing geographies for resource allocation
- **Visual:** Horizontal bar chart + map

### 7. Regional Growth Rate
- **Definition:** YoY revenue growth calculated independently per region
- **Formula:** `(Region 2024 Revenue − Region 2023 Revenue) ÷ Region 2023 Revenue × 100`
- **Purpose:** Flags at-risk regions that need intervention
- **Threshold:** ≥ 10% = High Growth | 0–10% = Stable | < 0% = At Risk

---

## Product KPIs

### 8. Category Contribution %
- **Definition:** Each product category's share of total revenue
- **Formula:** `Category Revenue ÷ Total Revenue × 100`
- **Purpose:** Shows portfolio mix; helps identify concentration risk
- **Visual:** Pie / doughnut chart

### 9. Top Product Performance
- **Definition:** Revenue ranking of product categories
- **Formula:** `SUM(Total_Revenue) GROUP BY Category, ranked DESC`
- **Purpose:** Highlights where the biggest revenue comes from
- **Visual:** Ranked bar chart (top 10)

---

## Profitability KPIs

### 10. Quarter-over-Quarter Growth
- **Definition:** Sequential revenue change from one quarter to the next
- **Formula:** `(Current Quarter Revenue − Previous Quarter Revenue) ÷ Previous Quarter Revenue × 100`
- **Purpose:** Tracks short-term momentum and seasonality
- **Visual:** Line chart with data labels

### 11. Profit Margin by Category
- **Definition:** Effective profit margin per product category
- **Formula:** `SUM(Profit) ÷ SUM(Total_Revenue) × 100` per category
- **Purpose:** Identifies high-margin vs low-margin categories for portfolio decisions
- **Visual:** Horizontal bar chart

---

## Customer KPIs

### 12. Customer Lifetime Value (LTV)
- **Definition:** Average total revenue generated per unique customer across all time
- **Formula:** `SUM(Total_Revenue) ÷ COUNT(DISTINCT Customer_ID)`
- **Purpose:** Measures long-term customer value; guides acquisition spend decisions
- **DAX:** `Avg LTV = SUMX(customers, total_spend) / COUNTROWS(customers)`

---

## Summary Table

| # | KPI | Category | Visual Type | Key Insight |
|---|-----|----------|-------------|-------------|
| 1 | Total Revenue | Revenue | KPI Card | Overall health |
| 2 | Revenue Growth (YoY) | Revenue | KPI Card + Trend | Growth momentum |
| 3 | Target Achievement % | Revenue | Gauge | Goal tracking |
| 4 | Average Order Value | Efficiency | KPI Card | Spend per visit |
| 5 | Transaction Volume | Efficiency | KPI Card | Demand level |
| 6 | Revenue per Region | Regional | Bar + Map | Geographic focus |
| 7 | Regional Growth Rate | Regional | Bar | Risk detection |
| 8 | Category Contribution % | Product | Pie Chart | Portfolio mix |
| 9 | Top Product Performance | Product | Ranked Bar | Revenue drivers |
| 10 | QoQ Growth | Profitability | Line Chart | Short-term trend |
| 11 | Profit Margin by Category | Profitability | Horizontal Bar | Margin analysis |
| 12 | Customer LTV | Customer | KPI Card | Customer value |
