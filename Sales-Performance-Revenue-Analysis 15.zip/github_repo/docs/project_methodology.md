# 🏗️ Project Methodology

## Overview

This document describes the end-to-end methodology followed to design, build, and deliver the Sales Performance & Revenue Analysis project — from data generation through SQL analysis, Python EDA, and Power BI dashboard development.

---

## Phase 1: Data Acquisition & Preparation

### 1.1 Dataset Design
A synthetic dataset was designed to simulate a realistic multi-region, multi-category sales environment. Key design decisions:

- **50,000 transactions** to ensure statistical significance across all slices
- **3-year span (2022–2024)** to enable meaningful YoY trend analysis
- **5 regions** with intentional performance variation (North strongest, West/Central weakest)
- **10 product categories** with varying growth rates and margins
- **~12,000 unique customers** to enable repeat-purchase and segmentation analysis

### 1.2 Data Generation
Python (`pandas`, `numpy`) was used to generate the dataset with controlled randomness:
- Regional performance modifiers control revenue distribution across geographies
- Category-level growth rates create realistic YoY trends
- Price variance (±15%) adds natural noise without destroying underlying signals
- Quantity follows a right-skewed distribution (most orders = 1 item)

### 1.3 Data Quality
- Zero null values across all 19 columns
- All Transaction_IDs are unique
- Revenue, Cost, and Profit calculations are internally consistent
- Quarterly targets are set as realistic benchmarks

---

## Phase 2: Database Design & SQL Analysis

### 2.1 Star Schema Design
A star schema was implemented for optimal query performance and Power BI compatibility:

```
FACT TABLE:      sales_fact          (50,000 rows)
DIMENSIONS:      time_dim            (1,096 rows — every date in range)
                 region_dim          (5 rows)
                 product_dim         (10 rows)
                 customer_dim        (derived from fact)
```

### 2.2 SQL Query Strategy
Eight query files were developed in logical sequence:

| File | Focus | Key Techniques |
|------|-------|----------------|
| `01_schema_setup.sql` | DDL + indexes | Star schema, foreign keys |
| `02_data_exploration.sql` | EDA in SQL | GROUP BY, COUNT, DISTINCT |
| `03_revenue_analysis.sql` | Revenue trends | Window functions, CTEs, cumulative sums |
| `04_regional_performance.sql` | Regional deep-dive | Self-joins, PARTITION BY, ranking |
| `05_product_analysis.sql` | Category analysis | ROW_NUMBER, classification logic |
| `06_yoy_growth.sql` | Growth metrics | LAG(), CAGR calculation, multi-year joins |
| `07_customer_analysis.sql` | Customer behaviour | RFM logic, gap analysis, cross-sell |
| `08_kpi_dashboard_queries.sql` | Power BI feed | Optimised views, all 12 KPIs |

### 2.3 Validation
- All SQL results cross-referenced against Python pandas calculations
- Achieved **95%+ accuracy** across all computed metrics
- Edge cases tested (zero values, single-region filters, boundary dates)

---

## Phase 3: Python Exploratory Analysis

### 3.1 EDA (`02_eda_analysis.py`)
Nine visualisations were generated covering:
- Revenue trends (yearly, quarterly)
- Regional and category breakdowns
- YoY growth comparison
- Sales channel distribution
- Profit margin distribution
- Correlation heatmap

### 3.2 Statistical Analysis (`03_statistical_analysis.py`)
- **Percentile analysis** of revenue, price, and profit
- **Outlier detection** using IQR method
- **Target vs Actual variance** analysis for all quarters
- **RFM-based customer segmentation** (Gold / Silver / Bronze)
- **At-risk region deep dive** with root-cause metrics
- **Category classification matrix** (Growth × Margin)

### 3.3 Automated Insights (`04_insights_report.py`)
A Markdown insights report is auto-generated from the dataset, including:
- Executive summary with key numbers
- KPI snapshot table
- Regional performance comparison
- High-growth category identification
- At-risk region analysis with recommendations
- Declining category monitoring

---

## Phase 4: Power BI Dashboard

### 4.1 Dashboard Architecture
The dashboard is organised into logical pages:

| Page | Content |
|------|---------|
| **Overview** | Total Revenue, Growth %, AOV, Transaction Volume |
| **Performance** | Target vs Actual, YoY Trends, QoQ Growth |
| **Products** | Category Contribution, Top Products, Margin Analysis |
| **Regions** | Regional Revenue, Growth Rates, At-Risk Flags |

### 4.2 Interactivity
- Date range slicers (Year, Quarter, Month)
- Region and Category filters
- Drill-through from summary → detail
- Conditional formatting for status indicators

### 4.3 DAX Measures
All 12 KPIs are implemented as DAX measures for dynamic recalculation:
- YoY comparisons use `CALCULATE` with date filters
- Percentage shares use `DIVIDE` for safe division
- Rankings use `RANKX` for dynamic ordering

---

## Accuracy & Validation

| Check | Method | Result |
|-------|--------|--------|
| Null values | Python + SQL | 0 nulls |
| Revenue consistency | Cross-ref Python ↔ SQL | ✓ Match |
| YoY calculations | Manual spot-check (3 categories) | ✓ Match |
| KPI formulas | DAX vs SQL vs Python | ✓ All agree |
| Overall accuracy | Validated metric suite | **95%+** |

---

## Tools & Libraries

| Tool | Version | Role |
|------|---------|------|
| Python | 3.11 | Data generation, EDA, statistics |
| Pandas | 2.1 | Data manipulation |
| NumPy | 1.26 | Numerical operations |
| Matplotlib | 3.8 | Chart generation |
| Seaborn | 0.13 | Statistical visualisations |
| Openpyxl | 3.1 | Excel formatting |
| PostgreSQL | 16 | Relational database |
| Power BI Desktop | Latest | Interactive dashboard |
