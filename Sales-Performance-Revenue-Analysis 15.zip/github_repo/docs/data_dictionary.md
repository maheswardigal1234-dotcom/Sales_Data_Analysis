# 📖 Data Dictionary

## Sales Transactions Dataset

| # | Field Name | Data Type | Nullable | Description | Example |
|---|-----------|-----------|----------|-------------|---------|
| 1 | `Transaction_ID` | TEXT | No | Unique identifier for each transaction. Format: `TXNxxxxxx` | `TXN001000` |
| 2 | `Date` | DATE | No | Transaction date | `2024-03-15` |
| 3 | `Year` | INT | No | Extracted year from Date | `2024` |
| 4 | `Quarter` | TEXT | No | Fiscal quarter label | `Q1`, `Q2`, `Q3`, `Q4` |
| 5 | `Month` | TEXT | No | Full month name | `January` |
| 6 | `Region` | TEXT | No | Geographic sales region | `North`, `South`, `East`, `West`, `Central` |
| 7 | `Category` | TEXT | No | Product category (10 total) | `Electronics` |
| 8 | `Product_Name` | TEXT | No | Product description | `Electronics Item` |
| 9 | `Customer_ID` | TEXT | No | Unique customer identifier. Format: `CUSTxxxxx` | `CUST03626` |
| 10 | `Quantity` | INT | No | Units purchased per transaction (1–5) | `2` |
| 11 | `Unit_Price` | NUMERIC | No | Price per single unit in USD | `448.89` |
| 12 | `Total_Revenue` | NUMERIC | No | `Unit_Price × Quantity` | `1346.67` |
| 13 | `Cost_Per_Unit` | NUMERIC | No | Cost of goods per unit | `291.78` |
| 14 | `Total_Cost` | NUMERIC | No | `Cost_Per_Unit × Quantity` | `875.34` |
| 15 | `Profit` | NUMERIC | No | `Total_Revenue − Total_Cost` | `471.33` |
| 16 | `Profit_Margin_%` | NUMERIC | No | `Profit ÷ Total_Revenue × 100` | `35.00` |
| 17 | `Sales_Channel` | TEXT | No | Purchase channel | `Online`, `In-Store`, `Mobile App` |
| 18 | `Payment_Method` | TEXT | No | Payment type used | `Credit Card`, `Debit Card`, `PayPal`, `Cash` |
| 19 | `Quarterly_Target_$K` | INT | No | Revenue target for the quarter in $000s | `3350` |

---

## Dimension Tables (Star Schema)

### `time_dim`
| Field | Type | Description |
|-------|------|-------------|
| `date_key` | DATE | Primary key — every calendar date in range |
| `year` | INT | Year |
| `quarter` | INT | Quarter number (1–4) |
| `quarter_label` | TEXT | `Q1`–`Q4` |
| `month_num` | INT | Month number (1–12) |
| `month_name` | TEXT | Full month name |
| `day` | INT | Day of month |
| `day_of_week` | TEXT | Day name |
| `is_weekend` | BOOL | TRUE if Saturday or Sunday |

### `region_dim`
| Field | Type | Description |
|-------|------|-------------|
| `region_id` | INT | Auto-increment PK |
| `region_name` | TEXT | Region name (unique) |
| `region_manager` | TEXT | Manager name |
| `annual_target` | NUMERIC | Annual revenue target ($) |

### `product_dim`
| Field | Type | Description |
|-------|------|-------------|
| `product_id` | INT | Auto-increment PK |
| `category` | TEXT | Category name |
| `product_name` | TEXT | Product description |
| `base_price` | NUMERIC | Base price before adjustments |
| `profit_margin` | NUMERIC | Target margin % |

### `customer_dim`
| Field | Type | Description |
|-------|------|-------------|
| `customer_id` | TEXT | Matches `sales_fact.customer_id` |
| `segment` | TEXT | Gold / Silver / Bronze |
| `first_purchase` | DATE | Date of first transaction |
| `region` | TEXT | Primary shopping region |

---

## Key Relationships

```
sales_fact.date_key     → time_dim.date_key
sales_fact.region_name  → region_dim.region_name
sales_fact.category     → product_dim.category
sales_fact.customer_id  → customer_dim.customer_id
```

---

## Category Reference

| Category | Base Price | Profit Margin | Growth Trend |
|----------|-----------|---------------|--------------|
| Electronics | $450 | 35% | ↑ High |
| Home & Garden | $280 | 32% | ↑ High |
| Sports & Outdoors | $320 | 30% | ↑ High |
| Clothing | $180 | 45% | ↑ Moderate |
| Books & Media | $85 | 28% | ↑ Moderate |
| Toys & Games | $120 | 38% | → Stable |
| Food & Beverage | $65 | 25% | → Stable |
| Health & Beauty | $95 | 42% | ↓ Slight |
| Automotive | $220 | 22% | ↓ Declining |
| Office Supplies | $75 | 35% | ↓ Declining |
