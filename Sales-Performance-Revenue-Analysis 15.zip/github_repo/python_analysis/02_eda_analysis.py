"""
02_eda_analysis.py
Exploratory Data Analysis — distributions, trends, breakdowns.
Generates charts saved to assets/ folder.
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import seaborn as sns
import os

# ─── Config ──────────────────────────────────────────────────
DATA_PATH   = os.path.join(os.path.dirname(__file__), '..', 'Sales_Data_Analysis.xlsx')
ASSETS_PATH = os.path.join(os.path.dirname(__file__), '..', 'assets')
os.makedirs(ASSETS_PATH, exist_ok=True)

plt.style.use('seaborn-v0_8-whitegrid')
PALETTE = ['#065A82', '#1C7293', '#02C39A', '#F59E0B', '#EF4444',
           '#6366F1', '#10B981', '#8B5CF6', '#EC4899', '#14B8A6']

# ─── Load ────────────────────────────────────────────────────
df = pd.read_excel(DATA_PATH, sheet_name='Sales_Transactions')
print(f"Loaded {len(df):,} rows × {df.shape[1]} columns")

# ─── 1. Shape & types ────────────────────────────────────────
print("\n── Column Types ──")
print(df.dtypes)
print(f"\n── Nulls ──\n{df.isnull().sum()}")
print(f"\n── Numeric Summary ──\n{df.describe()}")

# ─── 2. Revenue by Year (bar) ────────────────────────────────
fig, ax = plt.subplots(figsize=(9, 5))
yearly = df.groupby('Year')['Total_Revenue'].sum().reset_index()
bars = ax.bar(yearly['Year'].astype(str), yearly['Total_Revenue'],
              color=PALETTE[:3], width=0.5, edgecolor='white', linewidth=1.5)
for bar in bars:
    ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 40000,
            f"${bar.get_height():,.0f}", ha='center', fontsize=11, fontweight='bold', color='#21295C')
ax.set_title('Total Revenue by Year', fontsize=16, fontweight='bold', color='#065A82', pad=15)
ax.set_ylabel('Revenue ($)', fontsize=12)
ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f'${x/1e6:.1f}M'))
ax.spines[['top','right']].set_visible(False)
plt.tight_layout()
plt.savefig(os.path.join(ASSETS_PATH, 'revenue_by_year.png'), dpi=150)
plt.close()
print("✓ revenue_by_year.png")

# ─── 3. Revenue by Region (horizontal bar) ──────────────────
fig, ax = plt.subplots(figsize=(9, 5))
regional = df.groupby('Region')['Total_Revenue'].sum().sort_values()
colors = ['#EF4444' if r in ('West','Central') else '#1C7293' for r in regional.index]
bars = ax.barh(regional.index, regional.values, color=colors, height=0.5, edgecolor='white')
for bar in bars:
    ax.text(bar.get_width() + 30000, bar.get_y() + bar.get_height()/2,
            f"${bar.get_width():,.0f}", va='center', fontsize=11, fontweight='bold', color='#21295C')
ax.set_title('Revenue by Region', fontsize=16, fontweight='bold', color='#065A82', pad=15)
ax.set_xlabel('Revenue ($)', fontsize=12)
ax.xaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f'${x/1e6:.1f}M'))
ax.spines[['top','right']].set_visible(False)
# legend
from matplotlib.patches import Patch
legend_elements = [Patch(facecolor='#1C7293', label='On Track'),
                   Patch(facecolor='#EF4444', label='At Risk')]
ax.legend(handles=legend_elements, loc='lower right', fontsize=10)
plt.tight_layout()
plt.savefig(os.path.join(ASSETS_PATH, 'revenue_by_region.png'), dpi=150)
plt.close()
print("✓ revenue_by_region.png")

# ─── 4. Revenue by Category (bar, sorted) ───────────────────
fig, ax = plt.subplots(figsize=(11, 5))
cat_rev = df.groupby('Category')['Total_Revenue'].sum().sort_values(ascending=False)
ax.bar(range(len(cat_rev)), cat_rev.values, color=PALETTE[:len(cat_rev)], width=0.6, edgecolor='white')
ax.set_xticks(range(len(cat_rev)))
ax.set_xticklabels(cat_rev.index, rotation=30, ha='right', fontsize=10)
ax.set_title('Revenue by Product Category', fontsize=16, fontweight='bold', color='#065A82', pad=15)
ax.set_ylabel('Revenue ($)', fontsize=12)
ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f'${x/1e6:.1f}M'))
ax.spines[['top','right']].set_visible(False)
plt.tight_layout()
plt.savefig(os.path.join(ASSETS_PATH, 'revenue_by_category.png'), dpi=150)
plt.close()
print("✓ revenue_by_category.png")

# ─── 5. YoY Growth by Category (2023 → 2024) ────────────────
fig, ax = plt.subplots(figsize=(10, 5))
rev23 = df[df['Year']==2023].groupby('Category')['Total_Revenue'].sum()
rev24 = df[df['Year']==2024].groupby('Category')['Total_Revenue'].sum()
growth = ((rev24 - rev23) / rev23 * 100).sort_values(ascending=True)
colors = ['#10B981' if g >= 0 else '#EF4444' for g in growth.values]
ax.barh(growth.index, growth.values, color=colors, height=0.55, edgecolor='white')
ax.axvline(0, color='#21295C', linewidth=1)
ax.set_title('YoY Revenue Growth by Category (2023 → 2024)', fontsize=16, fontweight='bold', color='#065A82', pad=15)
ax.set_xlabel('Growth %', fontsize=12)
for i, v in enumerate(growth.values):
    ax.text(v + 0.3 if v >= 0 else v - 0.3, i, f'{v:.1f}%',
            va='center', ha='left' if v >= 0 else 'right', fontsize=10, fontweight='bold')
ax.spines[['top','right']].set_visible(False)
plt.tight_layout()
plt.savefig(os.path.join(ASSETS_PATH, 'yoy_growth_category.png'), dpi=150)
plt.close()
print("✓ yoy_growth_category.png")

# ─── 6. Quarterly Revenue — 2023 vs 2024 (grouped bar) ──────
fig, ax = plt.subplots(figsize=(9, 5))
q23 = df[df['Year']==2023].groupby('Quarter')['Total_Revenue'].sum()
q24 = df[df['Year']==2024].groupby('Quarter')['Total_Revenue'].sum()
x   = np.arange(len(q23))
w   = 0.35
ax.bar(x - w/2, q23.values, w, color='#64748B', label='2023', edgecolor='white')
ax.bar(x + w/2, q24.values, w, color='#1C7293', label='2024', edgecolor='white')
ax.set_xticks(x)
ax.set_xticklabels(q23.index)
ax.set_title('Quarterly Revenue: 2023 vs 2024', fontsize=16, fontweight='bold', color='#065A82', pad=15)
ax.set_ylabel('Revenue ($)', fontsize=12)
ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f'${x/1e6:.2f}M'))
ax.legend(fontsize=11)
ax.spines[['top','right']].set_visible(False)
plt.tight_layout()
plt.savefig(os.path.join(ASSETS_PATH, 'quarterly_comparison.png'), dpi=150)
plt.close()
print("✓ quarterly_comparison.png")

# ─── 7. Sales Channel Breakdown (pie) ───────────────────────
fig, ax = plt.subplots(figsize=(7, 7))
channel = df.groupby('Sales_Channel')['Total_Revenue'].sum()
wedges, texts, autotexts = ax.pie(
    channel.values, labels=channel.index, autopct='%1.1f%%',
    colors=PALETTE[:3], startangle=140, explode=[0.03]*len(channel),
    textprops={'fontsize': 12}, pctdistance=0.6
)
for at in autotexts:
    at.set_fontweight('bold')
    at.set_color('white')
ax.set_title('Revenue by Sales Channel', fontsize=16, fontweight='bold', color='#065A82', pad=15)
plt.tight_layout()
plt.savefig(os.path.join(ASSETS_PATH, 'sales_channel_pie.png'), dpi=150)
plt.close()
print("✓ sales_channel_pie.png")

# ─── 8. Profit Margin Distribution (histogram) ──────────────
fig, ax = plt.subplots(figsize=(9, 5))
ax.hist(df['Profit_Margin_%'], bins=20, color='#1C7293', edgecolor='white', linewidth=1.2)
ax.axvline(df['Profit_Margin_%'].mean(), color='#EF4444', linestyle='--', linewidth=2,
           label=f"Mean: {df['Profit_Margin_%'].mean():.1f}%")
ax.set_title('Distribution of Profit Margin %', fontsize=16, fontweight='bold', color='#065A82', pad=15)
ax.set_xlabel('Profit Margin (%)', fontsize=12)
ax.set_ylabel('Frequency', fontsize=12)
ax.legend(fontsize=11)
ax.spines[['top','right']].set_visible(False)
plt.tight_layout()
plt.savefig(os.path.join(ASSETS_PATH, 'profit_margin_dist.png'), dpi=150)
plt.close()
print("✓ profit_margin_dist.png")

# ─── 9. Correlation Heatmap ──────────────────────────────────
numeric_cols = ['Quantity','Unit_Price','Total_Revenue','Total_Cost','Profit','Profit_Margin_%']
fig, ax = plt.subplots(figsize=(8, 6))
sns.heatmap(df[numeric_cols].corr(), annot=True, fmt='.2f', cmap='coolwarm',
            center=0, linewidths=0.5, linecolor='white', ax=ax,
            cbar_kws={'shrink': 0.8})
ax.set_title('Correlation Matrix', fontsize=16, fontweight='bold', color='#065A82', pad=15)
plt.tight_layout()
plt.savefig(os.path.join(ASSETS_PATH, 'correlation_heatmap.png'), dpi=150)
plt.close()
print("✓ correlation_heatmap.png")

print("\n── All EDA charts saved to assets/ ──")
