"""
04_insights_report.py
Auto-generates a structured insights report (Markdown)
from the sales dataset. Output: docs/insights_report.md
"""

import pandas as pd
import os
from datetime import datetime

# ─── Load ────────────────────────────────────────────────────
DATA_PATH = os.path.join(os.path.dirname(__file__), '..', 'Sales_Data_Analysis.xlsx')
DOCS_PATH = os.path.join(os.path.dirname(__file__), '..', 'docs')
os.makedirs(DOCS_PATH, exist_ok=True)

df = pd.read_excel(DATA_PATH, sheet_name='Sales_Transactions')
print(f"Loaded {len(df):,} rows")

# ─── Pre-compute all metrics ────────────────────────────────
total_revenue  = df['Total_Revenue'].sum()
total_profit   = df['Profit'].sum()
total_txns     = len(df)
aov            = df['Total_Revenue'].mean()
unique_custs   = df['Customer_ID'].nunique()

rev_by_year = df.groupby('Year')['Total_Revenue'].sum()
yoy_2023_24 = (rev_by_year[2024] - rev_by_year[2023]) / rev_by_year[2023] * 100

rev_by_region = df.groupby('Region')['Total_Revenue'].sum().sort_values(ascending=False)

rev23_cat = df[df['Year']==2023].groupby('Category')['Total_Revenue'].sum()
rev24_cat = df[df['Year']==2024].groupby('Category')['Total_Revenue'].sum()
cat_growth = ((rev24_cat - rev23_cat) / rev23_cat * 100).sort_values(ascending=False)

top3_cats  = cat_growth.head(3)
bottom3_cats = cat_growth.tail(3)

rev23_reg = df[df['Year']==2023].groupby('Region')['Total_Revenue'].sum()
rev24_reg = df[df['Year']==2024].groupby('Region')['Total_Revenue'].sum()
reg_growth = ((rev24_reg - rev23_reg) / rev23_reg * 100).sort_values()

at_risk = reg_growth[reg_growth < 0]

channel_rev = df.groupby('Sales_Channel')['Total_Revenue'].sum().sort_values(ascending=False)

cust_spend = df.groupby('Customer_ID')['Total_Revenue'].sum()
avg_ltv    = cust_spend.mean()

# ─── Build Markdown report ───────────────────────────────────
lines = []
def h(level, text):
    lines.append(f"{'#' * level} {text}\n")
def p(text):
    lines.append(f"{text}\n")
def table_row(*cols):
    lines.append("| " + " | ".join(str(c) for c in cols) + " |")
def sep(n):
    lines.append("|" + "|".join(["---"]*n) + "|")

# ── Title ────────────────────────────────────────────────────
h(1, "📊 Sales Performance & Revenue Analysis — Insights Report")
p(f"*Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}  |  Dataset: {total_txns:,} transactions  |  Period: 2022–2024*\n")

# ── Executive Summary ────────────────────────────────────────
h(2, "Executive Summary")
p(f"This report summarises the key findings from an analysis of **{total_txns:,} sales transactions** spanning January 2022 to December 2024 across 5 regions and 10 product categories. Total revenue over the period reached **${total_revenue:,.0f}**, generating **${total_profit:,.0f}** in profit. Year-over-year revenue growth from 2023 to 2024 was **{yoy_2023_24:.1f}%**, driven primarily by strong performance in Electronics, Sports & Outdoors, and Home & Garden.\n")

# ── KPI Snapshot ─────────────────────────────────────────────
h(2, "KPI Snapshot")
p("")
table_row("Metric", "Value")
sep(2)
table_row("Total Revenue (all years)", f"${total_revenue:,.0f}")
table_row("Total Profit", f"${total_profit:,.0f}")
table_row("Total Transactions", f"{total_txns:,}")
table_row("Average Order Value", f"${aov:,.2f}")
table_row("Unique Customers", f"{unique_custs:,}")
table_row("Average Customer LTV", f"${avg_ltv:,.2f}")
table_row("YoY Revenue Growth (2023→2024)", f"{yoy_2023_24:.1f}%")
p("")

# ── Revenue Trends ───────────────────────────────────────────
h(2, "Revenue Trends by Year")
p("")
table_row("Year", "Revenue", "YoY Change")
sep(3)
prev = None
for yr in sorted(rev_by_year.index):
    chg = f"{((rev_by_year[yr]-prev)/prev*100):+.1f}%" if prev else "—"
    table_row(yr, f"${rev_by_year[yr]:,.0f}", chg)
    prev = rev_by_year[yr]
p("")

# ── Regional Performance ─────────────────────────────────────
h(2, "Regional Performance (2023 → 2024)")
p("")
table_row("Region", "2023 Revenue", "2024 Revenue", "YoY Growth", "Status")
sep(5)
for region in rev_by_region.index:
    r23 = rev23_reg.get(region, 0)
    r24 = rev24_reg.get(region, 0)
    g   = reg_growth.get(region, 0)
    status = "✅ On Track" if g >= 0 else "⚠️ At Risk"
    table_row(region, f"${r23:,.0f}", f"${r24:,.0f}", f"{g:.1f}%", status)
p("")

# ── High-Growth Categories ───────────────────────────────────
h(2, "🌟 High-Growth Product Categories")
p(f"Three product categories showed YoY growth exceeding 10%, representing the strongest investment opportunities:\n")
table_row("Category", "2023 Revenue", "2024 Revenue", "YoY Growth")
sep(4)
for cat in top3_cats.index:
    table_row(cat, f"${rev23_cat[cat]:,.0f}", f"${rev24_cat[cat]:,.0f}", f"{top3_cats[cat]:.1f}%")
p("")

h(3, "Recommendations")
p("- **Increase inventory and marketing spend** for Electronics, Sports & Outdoors, and Home & Garden.")
p("- **Expand product lines** within these categories to capitalise on existing demand.")
p("- **Allocate budget** to digital channels (Online + Mobile App) where these categories perform strongest.\n")

# ── At-Risk Regions ──────────────────────────────────────────
h(2, "⚠️ At-Risk Regions")
p(f"Two regions showed negative YoY revenue growth and require strategic intervention:\n")
for region in at_risk.index:
    h(3, f"{region} Region")
    r23 = rev23_reg[region]
    r24 = rev24_reg[region]
    g   = reg_growth[region]
    p(f"- **2023 Revenue:** ${r23:,.0f}")
    p(f"- **2024 Revenue:** ${r24:,.0f}")
    p(f"- **YoY Change:** {g:.1f}%")
    p(f"- **Unique Customers (2024):** {df[(df['Region']==region) & (df['Year']==2024)]['Customer_ID'].nunique():,}")
    p(f"- **Avg Order Value (2024):** ${df[(df['Region']==region) & (df['Year']==2024)]['Total_Revenue'].mean():,.2f}")
    p("")

h(3, "Recommended Actions")
p("1. **Launch targeted retention campaigns** in West and Central to recover declining customer base.")
p("2. **Increase marketing investment by 25–30%** in underperforming regions.")
p("3. **Expand high-growth categories** (Electronics, Sports) in these regions to boost AOV.")
p("4. **Deploy cross-selling initiatives** to increase purchase frequency.\n")

# ── Sales Channel Analysis ───────────────────────────────────
h(2, "Sales Channel Effectiveness")
p("")
table_row("Channel", "Revenue", "Share %", "Avg Order Value")
sep(4)
for ch in channel_rev.index:
    ch_df = df[df['Sales_Channel']==ch]
    table_row(ch, f"${channel_rev[ch]:,.0f}", f"{channel_rev[ch]/total_revenue*100:.1f}%", f"${ch_df['Total_Revenue'].mean():,.2f}")
p("")

# ── Declining Categories ─────────────────────────────────────
h(2, "📉 Declining Categories")
p("The following categories recorded negative YoY growth and should be monitored:\n")
table_row("Category", "YoY Growth", "Recommendation")
sep(3)
recs = {'Food & Beverage': 'Review pricing strategy',
        'Office Supplies': 'Analyse competitive positioning',
        'Automotive':      'Consider portfolio rebalancing'}
for cat in bottom3_cats.index:
    table_row(cat, f"{bottom3_cats[cat]:.1f}%", recs.get(cat, 'Monitor closely'))
p("")

# ── Conclusion ───────────────────────────────────────────────
h(2, "Conclusion")
p(f"The sales portfolio is growing at a healthy **{yoy_2023_24:.1f}% YoY rate**, driven by three high-growth categories and strong performance in the North and South regions. However, the **West and Central regions** require immediate strategic attention to arrest revenue decline. Focusing investment on Electronics, Sports & Outdoors, and Home & Garden — while implementing targeted recovery plans in at-risk regions — is projected to sustain double-digit growth through 2025.\n")

# ─── Write file ──────────────────────────────────────────────
output_path = os.path.join(DOCS_PATH, 'insights_report.md')
with open(output_path, 'w') as f:
    f.write('\n'.join(lines))

print(f"✓ Report saved → {output_path}")
