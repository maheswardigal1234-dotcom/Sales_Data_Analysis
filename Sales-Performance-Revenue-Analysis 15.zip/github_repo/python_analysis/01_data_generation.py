"""
01_data_generation.py
Generates a synthetic sales dataset with 50,000+ transactions.
Output: Sales_Data_Analysis.xlsx (placed in project root)
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import random
import os

np.random.seed(42)
random.seed(42)

# ─── Configuration ───────────────────────────────────────────
NUM_RECORDS  = 50000
START_DATE   = datetime(2022, 1, 1)
END_DATE     = datetime(2024, 12, 31)

REGIONS      = ['North', 'South', 'East', 'West', 'Central']
REGION_WEIGHTS = [0.25, 0.22, 0.21, 0.17, 0.15]

REGION_MODIFIER = {
    'North':   1.15,
    'South':   1.05,
    'East':    1.00,
    'West':    0.92,
    'Central': 0.85,
}

CATEGORIES = {
    'Electronics':        {'base_price': 450, 'growth': 0.285, 'margin': 0.35},
    'Home & Garden':      {'base_price': 280, 'growth': 0.262, 'margin': 0.32},
    'Sports & Outdoors':  {'base_price': 320, 'growth': 0.248, 'margin': 0.30},
    'Clothing':           {'base_price': 180, 'growth': 0.153, 'margin': 0.45},
    'Books & Media':      {'base_price':  85, 'growth': 0.121, 'margin': 0.28},
    'Toys & Games':       {'base_price': 120, 'growth': 0.085, 'margin': 0.38},
    'Food & Beverage':    {'base_price':  65, 'growth': 0.062, 'margin': 0.25},
    'Health & Beauty':    {'base_price':  95, 'growth': 0.038, 'margin': 0.42},
    'Automotive':         {'base_price': 220, 'growth':-0.021, 'margin': 0.22},
    'Office Supplies':    {'base_price':  75, 'growth':-0.045, 'margin': 0.35},
}

QUARTERLY_TARGETS = {
    (2022,1):2400, (2022,2):2650, (2022,3):2750, (2022,4):2850,
    (2023,1):2400, (2023,2):2650, (2023,3):2750, (2023,4):2850,
    (2024,1):2800, (2024,2):3100, (2024,3):3250, (2024,4):3350,
}

# ─── Generate dates ──────────────────────────────────────────
date_range = (END_DATE - START_DATE).days
dates = sorted([
    START_DATE + timedelta(days=random.randint(0, date_range))
    for _ in range(NUM_RECORDS)
])

# ─── Build records ───────────────────────────────────────────
records = []
txn_id  = 1000

for date in dates:
    year        = date.year
    year_factor = (year - 2022) / 2.0          # 0 → 0.5 → 1.0

    region   = np.random.choice(REGIONS, p=REGION_WEIGHTS)
    category = random.choice(list(CATEGORIES))
    cat      = CATEGORIES[category]

    # price = base × growth_adjustment × region_modifier × noise
    unit_price = (
        cat['base_price']
        * (1 + cat['growth'] * year_factor)
        * REGION_MODIFIER[region]
        * np.random.uniform(0.85, 1.15)
    )
    unit_price = round(unit_price, 2)

    quantity       = np.random.choice([1,2,3,4,5], p=[0.50,0.25,0.15,0.07,0.03])
    total_revenue  = round(unit_price * quantity, 2)
    cost_per_unit  = round(unit_price * (1 - cat['margin']), 2)
    total_cost     = round(cost_per_unit * quantity, 2)
    profit         = round(total_revenue - total_cost, 2)
    margin_pct     = round(profit / total_revenue * 100, 2) if total_revenue else 0

    quarter = (date.month - 1) // 3 + 1

    records.append({
        'Transaction_ID':      f'TXN{txn_id:06d}',
        'Date':                date.strftime('%Y-%m-%d'),
        'Year':                year,
        'Quarter':             f'Q{quarter}',
        'Month':               date.strftime('%B'),
        'Region':              region,
        'Category':            category,
        'Product_Name':        f'{category} Item',
        'Customer_ID':         f'CUST{random.randint(1,12000):05d}',
        'Quantity':            quantity,
        'Unit_Price':          unit_price,
        'Total_Revenue':       total_revenue,
        'Cost_Per_Unit':       cost_per_unit,
        'Total_Cost':          total_cost,
        'Profit':              profit,
        'Profit_Margin_%':     margin_pct,
        'Sales_Channel':       np.random.choice(['Online','In-Store','Mobile App'], p=[0.55,0.35,0.10]),
        'Payment_Method':      np.random.choice(['Credit Card','Debit Card','PayPal','Cash'], p=[0.45,0.30,0.15,0.10]),
        'Quarterly_Target_$K': QUARTERLY_TARGETS.get((year, quarter), 3000),
    })
    txn_id += 1

# ─── DataFrame & export ──────────────────────────────────────
df = pd.DataFrame(records)

output_path = os.path.join(os.path.dirname(__file__), '..', 'Sales_Data_Analysis.xlsx')
df.to_excel(output_path, index=False, sheet_name='Sales_Transactions')

# ─── Summary ─────────────────────────────────────────────────
print(f"✓ Generated {len(df):,} records")
print(f"  Date range   : {df['Date'].min()} → {df['Date'].max()}")
print(f"  Total revenue: ${df['Total_Revenue'].sum():,.2f}")
print(f"  Avg order    : ${df['Total_Revenue'].mean():,.2f}")
print(f"  Output       : {os.path.abspath(output_path)}")
