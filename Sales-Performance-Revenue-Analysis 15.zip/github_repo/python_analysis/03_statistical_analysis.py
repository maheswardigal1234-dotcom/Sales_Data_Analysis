"""
03_statistical_analysis.py
Deep statistical analysis: percentiles, outliers, segmentation,
customer cohorts, and variance calculations.
"""

import pandas as pd
import numpy as np
import os

# ─── Load ────────────────────────────────────────────────────
DATA_PATH = os.path.join(os.path.dirname(__file__), '..', 'Sales_Data_Analysis.xlsx')
df = pd.read_excel(DATA_PATH, sheet_name='Sales_Transactions')
print(f"Loaded {len(df):,} rows\n")

# ─── 1. Percentile breakdown of key metrics ─────────────────
print("=" * 60)
print("1. PERCENTILE ANALYSIS")
print("=" * 60)
for col in ['Unit_Price', 'Total_Revenue', 'Profit']:
    p = df[col].quantile([0.1, 0.25, 0.5, 0.75, 0.9, 0.95, 0.99])
    print(f"\n  {col}:")
    for pct, val in p.items():
        print(f"    P{int(pct*100):>3} : ${val:>10,.2f}")

# ─── 2. Outlier detection (IQR method) ───────────────────────
print("\n" + "=" * 60)
print("2. OUTLIER DETECTION (IQR)")
print("=" * 60)
for col in ['Total_Revenue', 'Unit_Price', 'Profit']:
    q1, q3 = df[col].quantile(0.25), df[col].quantile(0.75)
    iqr    = q3 - q1
    lower  = q1 - 1.5 * iqr
    upper  = q3 + 1.5 * iqr
    outliers = df[(df[col] < lower) | (df[col] > upper)]
    print(f"\n  {col}:")
    print(f"    IQR bounds : [${lower:,.2f}, ${upper:,.2f}]")
    print(f"    Outliers   : {len(outliers):,} ({len(outliers)/len(df)*100:.2f}%)")
    if len(outliers) > 0:
        print(f"    Outlier range: ${outliers[col].min():,.2f} – ${outliers[col].max():,.2f}")

# ─── 3. Revenue variance analysis (quarterly targets) ───────
print("\n" + "=" * 60)
print("3. TARGET vs ACTUAL — VARIANCE ANALYSIS")
print("=" * 60)
df['Q_Key'] = df['Year'].astype(str) + '-' + df['Quarter']
quarterly = (
    df.groupby(['Year', 'Quarter', 'Quarterly_Target_$K'])
    .agg(Actual_Revenue=('Total_Revenue', 'sum'))
    .reset_index()
)
quarterly['Target_Revenue']   = quarterly['Quarterly_Target_$K'] * 1000
quarterly['Variance']         = quarterly['Actual_Revenue'] - quarterly['Target_Revenue']
quarterly['Variance_Pct']     = (quarterly['Variance'] / quarterly['Target_Revenue'] * 100).round(2)
quarterly['Status']           = quarterly['Variance_Pct'].apply(
    lambda x: 'Above Target' if x >= 0 else ('Near Target' if x >= -10 else 'Below Target')
)
print(quarterly[['Year','Quarter','Target_Revenue','Actual_Revenue','Variance','Variance_Pct','Status']].to_string(index=False))

# ─── 4. Customer segmentation (RFM-style) ───────────────────
print("\n" + "=" * 60)
print("4. CUSTOMER SEGMENTATION")
print("=" * 60)
cust = df.groupby('Customer_ID').agg(
    Recency=('Date', 'max'),
    Frequency=('Transaction_ID', 'count'),
    Monetary=('Total_Revenue', 'sum')
).reset_index()
cust['Recency'] = pd.to_datetime(cust['Recency'])

# Score buckets (1-3 each)
cust['R_score'] = pd.qcut(cust['Recency'],  q=3, labels=[1,2,3])
cust['F_score'] = pd.qcut(cust['Frequency'], q=3, labels=[1,2,3], duplicates='drop')
cust['M_score'] = pd.qcut(cust['Monetary'],  q=3, labels=[1,2,3])
cust[['R_score','F_score','M_score']] = cust[['R_score','F_score','M_score']].astype(int)
cust['RFM_Score'] = cust['R_score'] + cust['F_score'] + cust['M_score']

cust['Segment'] = pd.cut(cust['RFM_Score'], bins=[2,4,6,9],
                         labels=['Bronze','Silver','Gold'])

seg_summary = cust.groupby('Segment').agg(
    Customers=('Customer_ID', 'count'),
    Avg_Monetary=('Monetary', 'mean'),
    Avg_Frequency=('Frequency', 'mean'),
    Total_Revenue=('Monetary', 'sum')
).round(2)
seg_summary['Rev_Share_%'] = (seg_summary['Total_Revenue'] / seg_summary['Total_Revenue'].sum() * 100).round(2)
print(seg_summary.to_string())

# ─── 5. Region deep-dive: West & Central (at-risk) ──────────
print("\n" + "=" * 60)
print("5. AT-RISK REGIONS DEEP DIVE")
print("=" * 60)
for region in ['West', 'Central']:
    r_df = df[df['Region'] == region]
    print(f"\n  ── {region} Region ──")
    print(f"    Total Revenue   : ${r_df['Total_Revenue'].sum():>12,.2f}")
    print(f"    Transactions    : {len(r_df):>12,}")
    print(f"    Unique Customers: {r_df['Customer_ID'].nunique():>12,}")
    print(f"    Avg Order Value : ${r_df['Total_Revenue'].mean():>12,.2f}")
    print(f"    Avg Margin %    : {r_df['Profit_Margin_%'].mean():>11.2f}%")
    # YoY
    r23 = r_df[r_df['Year']==2023]['Total_Revenue'].sum()
    r24 = r_df[r_df['Year']==2024]['Total_Revenue'].sum()
    yoy = (r24 - r23) / r23 * 100
    print(f"    2023 Revenue    : ${r23:>12,.2f}")
    print(f"    2024 Revenue    : ${r24:>12,.2f}")
    print(f"    YoY Growth      : {yoy:>11.2f}%")
    # Top category
    top_cat = r_df.groupby('Category')['Total_Revenue'].sum().idxmax()
    print(f"    Top Category    : {top_cat}")

# ─── 6. Category classification matrix ──────────────────────
print("\n" + "=" * 60)
print("6. CATEGORY CLASSIFICATION (Growth × Margin)")
print("=" * 60)
cat_stats = df.groupby('Category').agg(
    Revenue=('Total_Revenue', 'sum'),
    Avg_Margin=('Profit_Margin_%', 'mean')
).reset_index()

rev23 = df[df['Year']==2023].groupby('Category')['Total_Revenue'].sum()
rev24 = df[df['Year']==2024].groupby('Category')['Total_Revenue'].sum()
cat_stats['YoY_Growth'] = ((rev24 - rev23) / rev23 * 100).values

cat_stats['Classification'] = cat_stats.apply(lambda r:
    '⭐ Star'        if r['YoY_Growth'] >= 10 and r['Avg_Margin'] >= 30 else
    '📈 Growth'      if r['YoY_Growth'] >= 10                            else
    '💰 Profit'      if r['Avg_Margin'] >= 40                            else
    '📊 Stable'      if r['YoY_Growth'] >= 0                             else
    '⚠️  Watch'      if r['YoY_Growth'] >= -3                            else
    '🔻 Decline', axis=1
)
print(cat_stats.sort_values('YoY_Growth', ascending=False)[
    ['Category','Revenue','Avg_Margin','YoY_Growth','Classification']
].to_string(index=False))

# ─── 7. Sales channel effectiveness ─────────────────────────
print("\n" + "=" * 60)
print("7. SALES CHANNEL EFFECTIVENESS")
print("=" * 60)
ch = df.groupby('Sales_Channel').agg(
    Transactions=('Transaction_ID', 'count'),
    Revenue=('Total_Revenue', 'sum'),
    AOV=('Total_Revenue', 'mean'),
    Avg_Margin=('Profit_Margin_%', 'mean')
).round(2)
ch['Rev_Share_%']  = (ch['Revenue'] / ch['Revenue'].sum() * 100).round(2)
ch['Txn_Share_%']  = (ch['Transactions'] / ch['Transactions'].sum() * 100).round(2)
print(ch.to_string())

print("\n── Statistical analysis complete ──")
