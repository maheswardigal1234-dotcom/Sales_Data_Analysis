-- =============================================================
-- 04_regional_performance.sql
-- Regional breakdowns, rankings, comparisons, and risk flags
-- =============================================================

-- -------------------------------------------------------------
-- 1. Revenue by region (all-time)
-- -------------------------------------------------------------
SELECT
    region_name,
    ROUND(SUM(total_revenue), 2)     AS total_revenue,
    ROUND(SUM(profit), 2)            AS total_profit,
    COUNT(*)                         AS transactions,
    ROUND(AVG(total_revenue), 2)     AS avg_order_value,
    ROUND(AVG(profit_margin_pct), 2) AS avg_margin_pct,
    ROUND(
        SUM(total_revenue) * 100.0 /
        SUM(SUM(total_revenue)) OVER (), 2
    )                                AS revenue_share_pct
FROM sales_fact
GROUP BY region_name
ORDER BY total_revenue DESC;

-- -------------------------------------------------------------
-- 2. Revenue by region — each year side by side
-- -------------------------------------------------------------
SELECT
    region_name,
    ROUND(SUM(CASE WHEN EXTRACT(YEAR FROM date_key) = 2022 THEN total_revenue END), 2) AS rev_2022,
    ROUND(SUM(CASE WHEN EXTRACT(YEAR FROM date_key) = 2023 THEN total_revenue END), 2) AS rev_2023,
    ROUND(SUM(CASE WHEN EXTRACT(YEAR FROM date_key) = 2024 THEN total_revenue END), 2) AS rev_2024
FROM sales_fact
GROUP BY region_name
ORDER BY rev_2024 DESC;

-- -------------------------------------------------------------
-- 3. Year-over-Year growth per region (2023 → 2024)
-- -------------------------------------------------------------
WITH region_year AS (
    SELECT
        region_name,
        EXTRACT(YEAR FROM date_key)::INT AS year,
        ROUND(SUM(total_revenue), 2)     AS revenue
    FROM sales_fact
    GROUP BY region_name, year
)
SELECT
    r24.region_name,
    r23.revenue                                                             AS rev_2023,
    r24.revenue                                                             AS rev_2024,
    ROUND(r24.revenue - r23.revenue, 2)                                     AS change,
    ROUND((r24.revenue - r23.revenue) / r23.revenue * 100, 2)              AS yoy_growth_pct,
    CASE
        WHEN (r24.revenue - r23.revenue) / r23.revenue * 100 >= 10  THEN 'High Growth'
        WHEN (r24.revenue - r23.revenue) / r23.revenue * 100 >= 0   THEN 'Stable'
        WHEN (r24.revenue - r23.revenue) / r23.revenue * 100 >= -5  THEN 'At Risk'
        ELSE 'Declining'
    END AS status
FROM region_year r24
JOIN region_year r23
  ON r24.region_name = r23.region_name
 AND r23.year = 2023
WHERE r24.year = 2024
ORDER BY yoy_growth_pct DESC;

-- -------------------------------------------------------------
-- 4. Quarterly performance per region (2024)
-- -------------------------------------------------------------
SELECT
    region_name,
    'Q' || EXTRACT(QUARTER FROM date_key)::INT AS quarter,
    ROUND(SUM(total_revenue), 2)               AS revenue,
    COUNT(*)                                   AS transactions,
    ROUND(AVG(total_revenue), 2)               AS avg_order_value
FROM sales_fact
WHERE EXTRACT(YEAR FROM date_key) = 2024
GROUP BY region_name, quarter
ORDER BY region_name, quarter;

-- -------------------------------------------------------------
-- 5. Region ranking by revenue (dense rank)
-- -------------------------------------------------------------
SELECT
    region_name,
    ROUND(SUM(total_revenue), 2)  AS total_revenue,
    DENSE_RANK() OVER (ORDER BY SUM(total_revenue) DESC) AS revenue_rank
FROM sales_fact
WHERE EXTRACT(YEAR FROM date_key) = 2024
GROUP BY region_name
ORDER BY revenue_rank;

-- -------------------------------------------------------------
-- 6. Category mix per region (2024) — what sells where
-- -------------------------------------------------------------
WITH region_cat AS (
    SELECT
        region_name,
        category,
        ROUND(SUM(total_revenue), 2) AS revenue
    FROM sales_fact
    WHERE EXTRACT(YEAR FROM date_key) = 2024
    GROUP BY region_name, category
)
SELECT
    region_name,
    category,
    revenue,
    ROUND(
        revenue * 100.0 /
        SUM(revenue) OVER (PARTITION BY region_name), 2
    ) AS category_share_pct,
    RANK() OVER (PARTITION BY region_name ORDER BY revenue DESC) AS rank_in_region
FROM region_cat
ORDER BY region_name, rank_in_region;

-- -------------------------------------------------------------
-- 7. Average order value comparison across regions (2024)
-- -------------------------------------------------------------
SELECT
    region_name,
    ROUND(AVG(total_revenue), 2) AS avg_order_value,
    ROUND(AVG(total_revenue), 2) - ROUND(AVG(AVG(total_revenue)) OVER (), 2) AS diff_from_overall_avg
FROM sales_fact
WHERE EXTRACT(YEAR FROM date_key) = 2024
GROUP BY region_name
ORDER BY avg_order_value DESC;

-- -------------------------------------------------------------
-- 8. At-risk region deep-dive: West & Central
-- -------------------------------------------------------------
SELECT
    region_name,
    EXTRACT(YEAR FROM date_key)::INT AS year,
    COUNT(*)                         AS transactions,
    ROUND(SUM(total_revenue), 2)     AS revenue,
    ROUND(AVG(total_revenue), 2)     AS avg_order_value,
    COUNT(DISTINCT customer_id)      AS unique_customers,
    ROUND(
        COUNT(*)::NUMERIC /
        COUNT(DISTINCT customer_id), 2
    )                                AS avg_txns_per_customer
FROM sales_fact
WHERE region_name IN ('West', 'Central')
GROUP BY region_name, year
ORDER BY region_name, year;

-- -------------------------------------------------------------
-- 9. Sales channel effectiveness per region (2024)
-- -------------------------------------------------------------
SELECT
    region_name,
    sales_channel,
    COUNT(*)                      AS transactions,
    ROUND(SUM(total_revenue), 2)  AS revenue,
    ROUND(AVG(total_revenue), 2)  AS avg_order_value
FROM sales_fact
WHERE EXTRACT(YEAR FROM date_key) = 2024
GROUP BY region_name, sales_channel
ORDER BY region_name, revenue DESC;

-- -------------------------------------------------------------
-- 10. Top 3 categories per region (2024)
-- -------------------------------------------------------------
WITH ranked AS (
    SELECT
        region_name,
        category,
        ROUND(SUM(total_revenue), 2) AS revenue,
        ROW_NUMBER() OVER (
            PARTITION BY region_name
            ORDER BY SUM(total_revenue) DESC
        ) AS rn
    FROM sales_fact
    WHERE EXTRACT(YEAR FROM date_key) = 2024
    GROUP BY region_name, category
)
SELECT region_name, category, revenue
FROM ranked
WHERE rn <= 3
ORDER BY region_name, revenue DESC;
-- =============================================================
