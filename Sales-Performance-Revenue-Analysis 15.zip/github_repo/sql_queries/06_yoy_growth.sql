-- =============================================================
-- 06_yoy_growth.sql
-- Year-over-Year calculations using window functions & CTEs
-- =============================================================

-- -------------------------------------------------------------
-- 1. Overall YoY revenue & profit growth
-- -------------------------------------------------------------
WITH yearly AS (
    SELECT
        EXTRACT(YEAR FROM date_key)::INT AS year,
        ROUND(SUM(total_revenue), 2)     AS revenue,
        ROUND(SUM(profit), 2)            AS profit,
        COUNT(*)                         AS transactions,
        ROUND(AVG(total_revenue), 2)     AS avg_order_value
    FROM sales_fact
    GROUP BY year
)
SELECT
    year,
    revenue,
    profit,
    transactions,
    avg_order_value,
    -- Revenue YoY
    LAG(revenue) OVER (ORDER BY year)                                       AS prev_revenue,
    ROUND((revenue - LAG(revenue) OVER (ORDER BY year))
          / LAG(revenue) OVER (ORDER BY year) * 100, 2)                     AS revenue_yoy_pct,
    -- Profit YoY
    LAG(profit) OVER (ORDER BY year)                                        AS prev_profit,
    ROUND((profit - LAG(profit) OVER (ORDER BY year))
          / LAG(profit) OVER (ORDER BY year) * 100, 2)                      AS profit_yoy_pct,
    -- AOV YoY
    ROUND((avg_order_value - LAG(avg_order_value) OVER (ORDER BY year))
          / LAG(avg_order_value) OVER (ORDER BY year) * 100, 2)             AS aov_yoy_pct
FROM yearly
ORDER BY year;

-- -------------------------------------------------------------
-- 2. YoY growth per category (2023 → 2024)
-- -------------------------------------------------------------
WITH cat_year AS (
    SELECT
        category,
        EXTRACT(YEAR FROM date_key)::INT AS year,
        ROUND(SUM(total_revenue), 2)     AS revenue,
        ROUND(SUM(profit), 2)            AS profit,
        COUNT(*)                         AS transactions
    FROM sales_fact
    GROUP BY category, year
)
SELECT
    c24.category,
    c23.revenue                                                             AS rev_2023,
    c24.revenue                                                             AS rev_2024,
    ROUND(c24.revenue - c23.revenue, 2)                                     AS rev_change,
    ROUND((c24.revenue - c23.revenue) / c23.revenue * 100, 2)              AS rev_yoy_pct,
    c23.profit                                                              AS profit_2023,
    c24.profit                                                              AS profit_2024,
    ROUND((c24.profit - c23.profit) / c23.profit * 100, 2)                 AS profit_yoy_pct,
    CASE
        WHEN (c24.revenue - c23.revenue) / c23.revenue * 100 >= 15 THEN 'High Growth'
        WHEN (c24.revenue - c23.revenue) / c23.revenue * 100 >= 5  THEN 'Moderate Growth'
        WHEN (c24.revenue - c23.revenue) / c23.revenue * 100 >= 0  THEN 'Stable'
        ELSE 'Declining'
    END AS growth_status
FROM cat_year c24
JOIN cat_year c23 ON c24.category = c23.category AND c23.year = 2023
WHERE c24.year = 2024
ORDER BY rev_yoy_pct DESC;

-- -------------------------------------------------------------
-- 3. YoY growth per region (2023 → 2024)
-- -------------------------------------------------------------
WITH reg_year AS (
    SELECT
        region_name,
        EXTRACT(YEAR FROM date_key)::INT AS year,
        ROUND(SUM(total_revenue), 2)     AS revenue,
        COUNT(*)                         AS transactions,
        COUNT(DISTINCT customer_id)      AS unique_customers
    FROM sales_fact
    GROUP BY region_name, year
)
SELECT
    r24.region_name,
    r23.revenue                                                             AS rev_2023,
    r24.revenue                                                             AS rev_2024,
    ROUND((r24.revenue - r23.revenue) / r23.revenue * 100, 2)             AS rev_yoy_pct,
    r23.transactions                                                        AS txns_2023,
    r24.transactions                                                        AS txns_2024,
    ROUND((r24.transactions - r23.transactions)::NUMERIC
          / r23.transactions * 100, 2)                                      AS txns_yoy_pct,
    r23.unique_customers                                                    AS customers_2023,
    r24.unique_customers                                                    AS customers_2024,
    ROUND((r24.unique_customers - r23.unique_customers)::NUMERIC
          / r23.unique_customers * 100, 2)                                  AS customers_yoy_pct
FROM reg_year r24
JOIN reg_year r23 ON r24.region_name = r23.region_name AND r23.year = 2023
WHERE r24.year = 2024
ORDER BY rev_yoy_pct DESC;

-- -------------------------------------------------------------
-- 4. Quarterly YoY comparison (same quarter, different year)
-- -------------------------------------------------------------
WITH q_rev AS (
    SELECT
        EXTRACT(YEAR FROM date_key)::INT    AS year,
        EXTRACT(QUARTER FROM date_key)::INT AS quarter,
        ROUND(SUM(total_revenue), 2)        AS revenue
    FROM sales_fact
    GROUP BY year, quarter
)
SELECT
    q24.quarter                                                             AS quarter,
    q23.revenue                                                             AS rev_2023,
    q24.revenue                                                             AS rev_2024,
    ROUND(q24.revenue - q23.revenue, 2)                                     AS change,
    ROUND((q24.revenue - q23.revenue) / q23.revenue * 100, 2)             AS yoy_pct
FROM q_rev q24
JOIN q_rev q23 ON q24.quarter = q23.quarter AND q23.year = 2023
WHERE q24.year = 2024
ORDER BY q24.quarter;

-- -------------------------------------------------------------
-- 5. Monthly YoY (same month, 2023 vs 2024)
-- -------------------------------------------------------------
WITH m_rev AS (
    SELECT
        EXTRACT(YEAR  FROM date_key)::INT AS year,
        EXTRACT(MONTH FROM date_key)::INT AS month,
        ROUND(SUM(total_revenue), 2)      AS revenue
    FROM sales_fact
    GROUP BY year, month
)
SELECT
    m24.month,
    m23.revenue                                                             AS rev_2023,
    m24.revenue                                                             AS rev_2024,
    ROUND(m24.revenue - m23.revenue, 2)                                     AS change,
    ROUND((m24.revenue - m23.revenue) / m23.revenue * 100, 2)             AS yoy_pct
FROM m_rev m24
JOIN m_rev m23 ON m24.month = m23.month AND m23.year = 2023
WHERE m24.year = 2024
ORDER BY m24.month;

-- -------------------------------------------------------------
-- 6. Sales channel YoY growth (2023 → 2024)
-- -------------------------------------------------------------
WITH ch_year AS (
    SELECT
        sales_channel,
        EXTRACT(YEAR FROM date_key)::INT AS year,
        ROUND(SUM(total_revenue), 2)     AS revenue,
        COUNT(*)                         AS transactions
    FROM sales_fact
    GROUP BY sales_channel, year
)
SELECT
    c24.sales_channel,
    c23.revenue                                                             AS rev_2023,
    c24.revenue                                                             AS rev_2024,
    ROUND((c24.revenue - c23.revenue) / c23.revenue * 100, 2)             AS rev_yoy_pct,
    c23.transactions                                                        AS txns_2023,
    c24.transactions                                                        AS txns_2024,
    ROUND((c24.transactions - c23.transactions)::NUMERIC
          / c23.transactions * 100, 2)                                      AS txns_yoy_pct
FROM ch_year c24
JOIN ch_year c23 ON c24.sales_channel = c23.sales_channel AND c23.year = 2023
WHERE c24.year = 2024
ORDER BY rev_yoy_pct DESC;

-- -------------------------------------------------------------
-- 7. Compound Annual Growth Rate (CAGR) — 2022 to 2024
-- -------------------------------------------------------------
WITH endpoints AS (
    SELECT
        EXTRACT(YEAR FROM date_key)::INT AS year,
        ROUND(SUM(total_revenue), 2)     AS revenue
    FROM sales_fact
    GROUP BY year
)
SELECT
    (SELECT revenue FROM endpoints WHERE year = 2022) AS base_revenue_2022,
    (SELECT revenue FROM endpoints WHERE year = 2024) AS final_revenue_2024,
    ROUND(
        (
            POWER(
                (SELECT revenue FROM endpoints WHERE year = 2024)::NUMERIC /
                (SELECT revenue FROM endpoints WHERE year = 2022)::NUMERIC,
                1.0 / 2   -- 2 years between 2022 and 2024
            ) - 1
        ) * 100, 2
    ) AS cagr_pct;
-- =============================================================
