-- =============================================================
-- 05_product_analysis.sql
-- Product & category performance, rankings, and segmentation
-- =============================================================

-- -------------------------------------------------------------
-- 1. Revenue by category (all-time, ranked)
-- -------------------------------------------------------------
SELECT
    category,
    ROUND(SUM(total_revenue), 2)     AS total_revenue,
    ROUND(SUM(profit), 2)            AS total_profit,
    COUNT(*)                         AS transactions,
    ROUND(AVG(unit_price), 2)        AS avg_unit_price,
    ROUND(AVG(total_revenue), 2)     AS avg_order_value,
    ROUND(AVG(profit_margin_pct), 2) AS avg_margin_pct,
    DENSE_RANK() OVER (ORDER BY SUM(total_revenue) DESC) AS revenue_rank
FROM sales_fact
GROUP BY category
ORDER BY total_revenue DESC;

-- -------------------------------------------------------------
-- 2. Category revenue share (2024)
-- -------------------------------------------------------------
SELECT
    category,
    ROUND(SUM(total_revenue), 2) AS revenue,
    ROUND(
        SUM(total_revenue) * 100.0 /
        SUM(SUM(total_revenue)) OVER (), 2
    ) AS revenue_share_pct
FROM sales_fact
WHERE EXTRACT(YEAR FROM date_key) = 2024
GROUP BY category
ORDER BY revenue DESC;

-- -------------------------------------------------------------
-- 3. Profitability ranking by category
-- -------------------------------------------------------------
SELECT
    category,
    ROUND(SUM(total_revenue), 2)     AS revenue,
    ROUND(SUM(profit), 2)            AS profit,
    ROUND(SUM(profit) / SUM(total_revenue) * 100, 2) AS effective_margin_pct,
    DENSE_RANK() OVER (ORDER BY SUM(profit) DESC)     AS profit_rank
FROM sales_fact
WHERE EXTRACT(YEAR FROM date_key) = 2024
GROUP BY category
ORDER BY profit DESC;

-- -------------------------------------------------------------
-- 4. Quarterly trend per category (2024)
-- -------------------------------------------------------------
SELECT
    category,
    'Q' || EXTRACT(QUARTER FROM date_key)::INT AS quarter,
    ROUND(SUM(total_revenue), 2)               AS revenue,
    COUNT(*)                                   AS transactions
FROM sales_fact
WHERE EXTRACT(YEAR FROM date_key) = 2024
GROUP BY category, quarter
ORDER BY category, quarter;

-- -------------------------------------------------------------
-- 5. Top 5 categories by average order value (2024)
-- -------------------------------------------------------------
SELECT
    category,
    ROUND(AVG(total_revenue), 2)  AS avg_order_value,
    ROUND(AVG(unit_price), 2)     AS avg_unit_price,
    COUNT(*)                      AS transactions,
    DENSE_RANK() OVER (ORDER BY AVG(total_revenue) DESC) AS aov_rank
FROM sales_fact
WHERE EXTRACT(YEAR FROM date_key) = 2024
GROUP BY category
ORDER BY avg_order_value DESC
LIMIT 5;

-- -------------------------------------------------------------
-- 6. Category × Sales Channel matrix (2024)
-- -------------------------------------------------------------
SELECT
    category,
    sales_channel,
    COUNT(*)                      AS transactions,
    ROUND(SUM(total_revenue), 2)  AS revenue
FROM sales_fact
WHERE EXTRACT(YEAR FROM date_key) = 2024
GROUP BY category, sales_channel
ORDER BY category, revenue DESC;

-- -------------------------------------------------------------
-- 7. High-value transactions per category (top 5 per category)
-- -------------------------------------------------------------
WITH ranked_txns AS (
    SELECT
        *,
        ROW_NUMBER() OVER (
            PARTITION BY category
            ORDER BY total_revenue DESC
        ) AS rn
    FROM sales_fact
    WHERE EXTRACT(YEAR FROM date_key) = 2024
)
SELECT
    transaction_id,
    category,
    date_key,
    region_name,
    quantity,
    unit_price,
    total_revenue,
    profit
FROM ranked_txns
WHERE rn <= 5
ORDER BY category, total_revenue DESC;

-- -------------------------------------------------------------
-- 8. Category performance classification
-- -------------------------------------------------------------
WITH cat_stats AS (
    SELECT
        category,
        ROUND(SUM(total_revenue), 2) AS revenue,
        ROUND(AVG(profit_margin_pct), 2) AS avg_margin,
        ROUND(
            (SUM(CASE WHEN EXTRACT(YEAR FROM date_key) = 2024 THEN total_revenue END) -
             SUM(CASE WHEN EXTRACT(YEAR FROM date_key) = 2023 THEN total_revenue END)) /
            NULLIF(SUM(CASE WHEN EXTRACT(YEAR FROM date_key) = 2023 THEN total_revenue END), 0) * 100, 2
        ) AS yoy_growth_pct
    FROM sales_fact
    GROUP BY category
)
SELECT
    category,
    revenue,
    avg_margin,
    yoy_growth_pct,
    CASE
        WHEN yoy_growth_pct >= 15 AND avg_margin >= 30 THEN '⭐ Star (High Growth + High Margin)'
        WHEN yoy_growth_pct >= 10                        THEN '📈 Growth'
        WHEN yoy_growth_pct >= 0                         THEN '📊 Stable'
        WHEN yoy_growth_pct >= -5                        THEN '⚠️  Watch'
        ELSE                                                  '🔻 Decline'
    END AS classification
FROM cat_stats
ORDER BY yoy_growth_pct DESC;

-- -------------------------------------------------------------
-- 9. Revenue per transaction (quantity-adjusted) by category
-- -------------------------------------------------------------
SELECT
    category,
    ROUND(SUM(total_revenue), 2)                          AS total_revenue,
    SUM(quantity)                                         AS total_units_sold,
    ROUND(SUM(total_revenue) / SUM(quantity), 2)          AS revenue_per_unit,
    ROUND(AVG(quantity), 2)                               AS avg_quantity_per_order
FROM sales_fact
WHERE EXTRACT(YEAR FROM date_key) = 2024
GROUP BY category
ORDER BY revenue_per_unit DESC;

-- -------------------------------------------------------------
-- 10. Seasonal pattern by category (monthly avg revenue, 2024)
-- -------------------------------------------------------------
SELECT
    category,
    EXTRACT(MONTH FROM date_key)::INT AS month,
    ROUND(AVG(total_revenue), 2)      AS avg_monthly_revenue,
    COUNT(*)                          AS transactions
FROM sales_fact
WHERE EXTRACT(YEAR FROM date_key) = 2024
GROUP BY category, month
ORDER BY category, month;
-- =============================================================
