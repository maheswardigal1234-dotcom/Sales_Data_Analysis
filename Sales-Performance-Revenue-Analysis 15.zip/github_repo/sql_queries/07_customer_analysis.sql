-- =============================================================
-- 07_customer_analysis.sql
-- Customer segmentation, lifetime value, retention & behaviour
-- =============================================================

-- -------------------------------------------------------------
-- 1. Customer summary: spend, frequency, first/last purchase
-- -------------------------------------------------------------
SELECT
    customer_id,
    COUNT(*)                          AS total_transactions,
    ROUND(SUM(total_revenue), 2)      AS total_spend,
    ROUND(AVG(total_revenue), 2)      AS avg_order_value,
    MIN(date_key)                     AS first_purchase,
    MAX(date_key)                     AS last_purchase,
    COUNT(DISTINCT region_name)       AS regions_shopped,
    COUNT(DISTINCT category)          AS categories_shopped
FROM sales_fact
GROUP BY customer_id
ORDER BY total_spend DESC
LIMIT 20;

-- -------------------------------------------------------------
-- 2. Customer segmentation (Gold / Silver / Bronze)
-- Based on total spend thresholds
-- -------------------------------------------------------------
WITH cust_spend AS (
    SELECT
        customer_id,
        ROUND(SUM(total_revenue), 2) AS total_spend,
        COUNT(*)                     AS transactions
    FROM sales_fact
    GROUP BY customer_id
)
SELECT
    CASE
        WHEN total_spend >= 3000 THEN 'Gold'
        WHEN total_spend >= 1500 THEN 'Silver'
        ELSE                          'Bronze'
    END                                                        AS segment,
    COUNT(*)                                                   AS customer_count,
    ROUND(SUM(total_spend), 2)                                 AS segment_revenue,
    ROUND(AVG(total_spend), 2)                                 AS avg_spend,
    ROUND(AVG(transactions), 2)                                AS avg_transactions,
    ROUND(SUM(total_spend) * 100.0 /
          SUM(SUM(total_spend)) OVER (), 2)                    AS revenue_share_pct
FROM cust_spend
GROUP BY segment
ORDER BY avg_spend DESC;

-- -------------------------------------------------------------
-- 3. Top 10 customers by lifetime value (2024)
-- -------------------------------------------------------------
SELECT
    customer_id,
    COUNT(*)                      AS transactions,
    ROUND(SUM(total_revenue), 2)  AS lifetime_value,
    ROUND(AVG(total_revenue), 2)  AS avg_order_value,
    COUNT(DISTINCT category)      AS categories_purchased,
    COUNT(DISTINCT region_name)   AS regions_shopped,
    MIN(date_key)                 AS first_purchase,
    MAX(date_key)                 AS last_purchase
FROM sales_fact
WHERE EXTRACT(YEAR FROM date_key) = 2024
GROUP BY customer_id
ORDER BY lifetime_value DESC
LIMIT 10;

-- -------------------------------------------------------------
-- 4. Customer frequency distribution
-- -------------------------------------------------------------
WITH cust_txn AS (
    SELECT customer_id, COUNT(*) AS txn_count
    FROM sales_fact
    GROUP BY customer_id
)
SELECT
    CASE
        WHEN txn_count = 1            THEN '1 (One-time)'
        WHEN txn_count BETWEEN 2 AND 3 THEN '2-3'
        WHEN txn_count BETWEEN 4 AND 6 THEN '4-6'
        WHEN txn_count BETWEEN 7 AND 10 THEN '7-10'
        ELSE                               '10+'
    END                                  AS frequency_bucket,
    COUNT(*)                             AS customer_count,
    ROUND(SUM(txn_count)::NUMERIC /
          (SELECT COUNT(*) FROM sales_fact) * 100, 2) AS txn_share_pct
FROM cust_txn
GROUP BY frequency_bucket
ORDER BY MIN(txn_count);

-- -------------------------------------------------------------
-- 5. Repeat vs one-time customer revenue comparison
-- -------------------------------------------------------------
WITH cust_type AS (
    SELECT
        customer_id,
        COUNT(*)                      AS txn_count,
        ROUND(SUM(total_revenue), 2)  AS total_spend
    FROM sales_fact
    GROUP BY customer_id
)
SELECT
    CASE WHEN txn_count = 1 THEN 'One-Time' ELSE 'Repeat' END AS customer_type,
    COUNT(*)                                                   AS customer_count,
    ROUND(SUM(total_spend), 2)                                 AS total_revenue,
    ROUND(AVG(total_spend), 2)                                 AS avg_spend_per_customer,
    ROUND(SUM(total_spend) * 100.0 /
          SUM(SUM(total_spend)) OVER (), 2)                    AS revenue_share_pct
FROM cust_type
GROUP BY customer_type
ORDER BY total_revenue DESC;

-- -------------------------------------------------------------
-- 6. Preferred category per customer (top spend category)
-- -------------------------------------------------------------
WITH cust_cat AS (
    SELECT
        customer_id,
        category,
        ROUND(SUM(total_revenue), 2) AS spend,
        ROW_NUMBER() OVER (
            PARTITION BY customer_id
            ORDER BY SUM(total_revenue) DESC
        ) AS rn
    FROM sales_fact
    GROUP BY customer_id, category
)
SELECT
    category                    AS preferred_category,
    COUNT(*)                    AS customer_count,
    ROUND(AVG(spend), 2)        AS avg_spend_in_category
FROM cust_cat
WHERE rn = 1
GROUP BY category
ORDER BY customer_count DESC;

-- -------------------------------------------------------------
-- 7. Customer acquisition by year
-- -------------------------------------------------------------
WITH first_purchase AS (
    SELECT
        customer_id,
        MIN(date_key) AS first_date
    FROM sales_fact
    GROUP BY customer_id
)
SELECT
    EXTRACT(YEAR FROM first_date)::INT AS acquisition_year,
    COUNT(*)                           AS new_customers,
    ROUND(
        COUNT(*) * 100.0 /
        SUM(COUNT(*)) OVER (), 2
    )                                  AS pct_of_total
FROM first_purchase
GROUP BY acquisition_year
ORDER BY acquisition_year;

-- -------------------------------------------------------------
-- 8. Cross-sell indicator: customers buying 3+ categories
-- -------------------------------------------------------------
WITH cust_cats AS (
    SELECT
        customer_id,
        COUNT(DISTINCT category) AS categories_bought,
        ROUND(SUM(total_revenue), 2) AS total_spend
    FROM sales_fact
    GROUP BY customer_id
)
SELECT
    CASE
        WHEN categories_bought >= 7 THEN '7+ categories'
        WHEN categories_bought >= 5 THEN '5-6 categories'
        WHEN categories_bought >= 3 THEN '3-4 categories'
        ELSE                              '1-2 categories'
    END                             AS diversity_bucket,
    COUNT(*)                        AS customer_count,
    ROUND(AVG(total_spend), 2)      AS avg_total_spend,
    ROUND(AVG(categories_bought), 2) AS avg_categories
FROM cust_cats
GROUP BY diversity_bucket
ORDER BY MIN(categories_bought) DESC;

-- -------------------------------------------------------------
-- 9. Average days between purchases (per customer, top 10)
-- -------------------------------------------------------------
WITH txn_gaps AS (
    SELECT
        customer_id,
        date_key,
        LAG(date_key) OVER (PARTITION BY customer_id ORDER BY date_key) AS prev_date
    FROM sales_fact
)
SELECT
    customer_id,
    COUNT(*)                                               AS total_purchases,
    ROUND(AVG((date_key - prev_date)::NUMERIC), 1)        AS avg_days_between_purchases
FROM txn_gaps
WHERE prev_date IS NOT NULL
GROUP BY customer_id
HAVING COUNT(*) >= 5
ORDER BY avg_days_between_purchases ASC
LIMIT 10;

-- -------------------------------------------------------------
-- 10. Customer channel preference
-- -------------------------------------------------------------
WITH cust_channel AS (
    SELECT
        customer_id,
        sales_channel,
        COUNT(*) AS txn_count,
        ROW_NUMBER() OVER (
            PARTITION BY customer_id
            ORDER BY COUNT(*) DESC
        ) AS rn
    FROM sales_fact
    GROUP BY customer_id, sales_channel
)
SELECT
    sales_channel                AS preferred_channel,
    COUNT(*)                     AS customer_count,
    ROUND(
        COUNT(*) * 100.0 /
        SUM(COUNT(*)) OVER (), 2
    )                            AS pct_of_customers
FROM cust_channel
WHERE rn = 1
GROUP BY sales_channel
ORDER BY customer_count DESC;
-- =============================================================
