-- =============================================================
-- 08_kpi_dashboard_queries.sql
-- Optimized queries for Power BI dashboard integration
-- Each query maps to a specific KPI or visual on the dashboard
-- =============================================================

-- -------------------------------------------------------------
-- KPI 1: Total Revenue (current year with comparison)
-- -------------------------------------------------------------
SELECT
    EXTRACT(YEAR FROM date_key)::INT AS year,
    ROUND(SUM(total_revenue), 2)     AS total_revenue,
    ROUND(SUM(profit), 2)            AS total_profit,
    COUNT(*)                         AS total_transactions,
    ROUND(AVG(total_revenue), 2)     AS avg_order_value
FROM sales_fact
GROUP BY year
ORDER BY year;

-- -------------------------------------------------------------
-- KPI 2: Revenue Growth Rate (YoY) — single value for card
-- -------------------------------------------------------------
WITH yearly AS (
    SELECT
        EXTRACT(YEAR FROM date_key)::INT AS year,
        ROUND(SUM(total_revenue), 2)     AS revenue
    FROM sales_fact
    GROUP BY year
    ORDER BY year DESC
    LIMIT 2
)
SELECT
    MAX(CASE WHEN year = 2024 THEN revenue END)                                  AS current_revenue,
    MAX(CASE WHEN year = 2023 THEN revenue END)                                  AS prior_revenue,
    ROUND(
        (MAX(CASE WHEN year = 2024 THEN revenue END) -
         MAX(CASE WHEN year = 2023 THEN revenue END)) /
         MAX(CASE WHEN year = 2023 THEN revenue END) * 100, 2
    )                                                                             AS yoy_growth_pct
FROM yearly;

-- -------------------------------------------------------------
-- KPI 3: Target vs Achievement (quarterly)
-- -------------------------------------------------------------
SELECT
    EXTRACT(YEAR FROM date_key)::INT    AS year,
    EXTRACT(QUARTER FROM date_key)::INT AS quarter,
    'Q' || EXTRACT(QUARTER FROM date_key)::INT AS quarter_label,
    ROUND(SUM(total_revenue), 2)        AS actual_revenue,
    MIN(quarterly_target_k) * 1000      AS target_revenue,
    ROUND(
        SUM(total_revenue) /
        (MIN(quarterly_target_k) * 1000) * 100, 2
    )                                   AS achievement_pct
FROM sales_fact
GROUP BY year, quarter
ORDER BY year, quarter;

-- -------------------------------------------------------------
-- KPI 4: Average Order Value trend (monthly)
-- -------------------------------------------------------------
SELECT
    EXTRACT(YEAR  FROM date_key)::INT AS year,
    EXTRACT(MONTH FROM date_key)::INT AS month,
    ROUND(AVG(total_revenue), 2)      AS avg_order_value,
    COUNT(*)                          AS transactions
FROM sales_fact
GROUP BY year, month
ORDER BY year, month;

-- -------------------------------------------------------------
-- KPI 5: Transaction Volume (by region + time)
-- -------------------------------------------------------------
SELECT
    EXTRACT(YEAR FROM date_key)::INT    AS year,
    EXTRACT(QUARTER FROM date_key)::INT AS quarter,
    region_name,
    COUNT(*)                            AS transaction_count,
    ROUND(SUM(total_revenue), 2)        AS revenue
FROM sales_fact
GROUP BY year, quarter, region_name
ORDER BY year, quarter, region_name;

-- -------------------------------------------------------------
-- KPI 6: Revenue per Region (with target comparison)
-- -------------------------------------------------------------
SELECT
    sf.region_name,
    ROUND(SUM(sf.total_revenue), 2)     AS actual_revenue,
    rd.annual_target                    AS target_revenue,
    ROUND(
        SUM(sf.total_revenue) /
        rd.annual_target * 100, 2
    )                                   AS achievement_pct,
    ROUND(SUM(sf.total_revenue) - rd.annual_target, 2) AS variance
FROM sales_fact sf
JOIN region_dim rd ON sf.region_name = rd.region_name
WHERE EXTRACT(YEAR FROM sf.date_key) = 2024
GROUP BY sf.region_name, rd.annual_target
ORDER BY actual_revenue DESC;

-- -------------------------------------------------------------
-- KPI 7: Category Contribution % (pie chart data)
-- -------------------------------------------------------------
SELECT
    category,
    ROUND(SUM(total_revenue), 2)  AS revenue,
    ROUND(
        SUM(total_revenue) * 100.0 /
        SUM(SUM(total_revenue)) OVER (), 2
    )                             AS contribution_pct
FROM sales_fact
WHERE EXTRACT(YEAR FROM date_key) = 2024
GROUP BY category
ORDER BY revenue DESC;

-- -------------------------------------------------------------
-- KPI 8: Top Product Performance (top 10 categories ranked)
-- -------------------------------------------------------------
SELECT
    category,
    ROUND(SUM(total_revenue), 2)     AS revenue,
    ROUND(SUM(profit), 2)            AS profit,
    COUNT(*)                         AS transactions,
    ROUND(AVG(total_revenue), 2)     AS avg_order_value,
    ROUND(AVG(profit_margin_pct), 2) AS avg_margin_pct,
    DENSE_RANK() OVER (ORDER BY SUM(total_revenue) DESC) AS rank
FROM sales_fact
WHERE EXTRACT(YEAR FROM date_key) = 2024
GROUP BY category
ORDER BY revenue DESC;

-- -------------------------------------------------------------
-- KPI 9: Regional Growth Rate (YoY bar chart)
-- -------------------------------------------------------------
WITH reg_yr AS (
    SELECT
        region_name,
        EXTRACT(YEAR FROM date_key)::INT AS year,
        ROUND(SUM(total_revenue), 2)     AS revenue
    FROM sales_fact
    GROUP BY region_name, year
)
SELECT
    r24.region_name,
    r23.revenue                                                            AS rev_2023,
    r24.revenue                                                            AS rev_2024,
    ROUND((r24.revenue - r23.revenue) / r23.revenue * 100, 2)            AS growth_pct,
    CASE
        WHEN (r24.revenue - r23.revenue) / r23.revenue * 100 >= 10  THEN 'High Growth'
        WHEN (r24.revenue - r23.revenue) / r23.revenue * 100 >= 0   THEN 'Stable'
        WHEN (r24.revenue - r23.revenue) / r23.revenue * 100 >= -5  THEN 'At Risk'
        ELSE 'Declining'
    END AS status
FROM reg_yr r24
JOIN reg_yr r23 ON r24.region_name = r23.region_name AND r23.year = 2023
WHERE r24.year = 2024
ORDER BY growth_pct DESC;

-- -------------------------------------------------------------
-- KPI 10: Quarter-over-Quarter Growth (line chart)
-- -------------------------------------------------------------
WITH qtr AS (
    SELECT
        EXTRACT(YEAR FROM date_key)::INT    AS year,
        EXTRACT(QUARTER FROM date_key)::INT AS quarter,
        ROUND(SUM(total_revenue), 2)        AS revenue
    FROM sales_fact
    GROUP BY year, quarter
    ORDER BY year, quarter
)
SELECT
    year,
    'Q' || quarter                                                              AS quarter_label,
    revenue,
    LAG(revenue) OVER (ORDER BY year, quarter)                                  AS prev_revenue,
    ROUND((revenue - LAG(revenue) OVER (ORDER BY year, quarter))
          / LAG(revenue) OVER (ORDER BY year, quarter) * 100, 2)               AS qoq_growth_pct
FROM qtr
ORDER BY year, quarter;

-- -------------------------------------------------------------
-- KPI 11: Profit Margin by Category (horizontal bar)
-- -------------------------------------------------------------
SELECT
    category,
    ROUND(SUM(total_revenue), 2)                              AS revenue,
    ROUND(SUM(profit), 2)                                     AS profit,
    ROUND(SUM(profit) / SUM(total_revenue) * 100, 2)         AS effective_margin_pct,
    ROUND(AVG(profit_margin_pct), 2)                          AS avg_margin_pct
FROM sales_fact
WHERE EXTRACT(YEAR FROM date_key) = 2024
GROUP BY category
ORDER BY effective_margin_pct DESC;

-- -------------------------------------------------------------
-- KPI 12: Customer Lifetime Value (summary)
-- -------------------------------------------------------------
WITH cust AS (
    SELECT
        customer_id,
        ROUND(SUM(total_revenue), 2) AS lifetime_value,
        COUNT(*)                     AS total_transactions
    FROM sales_fact
    GROUP BY customer_id
)
SELECT
    COUNT(*)                             AS total_customers,
    ROUND(AVG(lifetime_value), 2)        AS avg_lifetime_value,
    ROUND(SUM(lifetime_value), 2)        AS total_customer_revenue,
    ROUND(MIN(lifetime_value), 2)        AS min_ltv,
    ROUND(MAX(lifetime_value), 2)        AS max_ltv,
    ROUND(AVG(total_transactions), 2)    AS avg_purchase_frequency
FROM cust;

-- -------------------------------------------------------------
-- MASTER VIEW: Full fact with computed columns for Power BI
-- Create as a VIEW for direct dashboard consumption
-- -------------------------------------------------------------
CREATE OR REPLACE VIEW dashboard_master AS
SELECT
    sf.transaction_id,
    sf.date_key,
    EXTRACT(YEAR  FROM sf.date_key)::INT    AS year,
    EXTRACT(QUARTER FROM sf.date_key)::INT  AS quarter,
    'Q' || EXTRACT(QUARTER FROM sf.date_key)::INT AS quarter_label,
    EXTRACT(MONTH FROM sf.date_key)::INT    AS month_num,
    sf.region_name,
    sf.category,
    sf.customer_id,
    sf.quantity,
    sf.unit_price,
    sf.total_revenue,
    sf.total_cost,
    sf.profit,
    sf.profit_margin_pct,
    sf.sales_channel,
    sf.payment_method,
    sf.quarterly_target_k,
    sf.quarterly_target_k * 1000            AS quarterly_target_dollars,
    rd.annual_target                        AS region_annual_target
FROM sales_fact sf
LEFT JOIN region_dim rd ON sf.region_name = rd.region_name;
-- =============================================================
