-- =============================================================
-- 02_data_exploration.sql
-- Basic exploration: shape, samples, distributions, nulls
-- =============================================================

-- -------------------------------------------------------------
-- 1. Row count & column overview
-- -------------------------------------------------------------
SELECT COUNT(*) AS total_rows FROM sales_fact;

SELECT
    column_name,
    data_type,
    is_nullable
FROM information_schema.columns
WHERE table_name = 'sales_fact'
ORDER BY ordinal_position;

-- -------------------------------------------------------------
-- 2. Sample rows
-- -------------------------------------------------------------
SELECT * FROM sales_fact
ORDER BY date_key ASC
LIMIT 10;

-- -------------------------------------------------------------
-- 3. Date range
-- -------------------------------------------------------------
SELECT
    MIN(date_key)           AS earliest_date,
    MAX(date_key)           AS latest_date,
    COUNT(DISTINCT date_key) AS unique_days
FROM sales_fact;

-- -------------------------------------------------------------
-- 4. Null / missing value check (should all return 0)
-- -------------------------------------------------------------
SELECT
    COUNT(*) FILTER (WHERE transaction_id   IS NULL) AS null_transaction_id,
    COUNT(*) FILTER (WHERE date_key         IS NULL) AS null_date,
    COUNT(*) FILTER (WHERE region_name      IS NULL) AS null_region,
    COUNT(*) FILTER (WHERE category         IS NULL) AS null_category,
    COUNT(*) FILTER (WHERE customer_id      IS NULL) AS null_customer,
    COUNT(*) FILTER (WHERE quantity         IS NULL) AS null_quantity,
    COUNT(*) FILTER (WHERE total_revenue    IS NULL) AS null_revenue,
    COUNT(*) FILTER (WHERE profit           IS NULL) AS null_profit
FROM sales_fact;

-- -------------------------------------------------------------
-- 5. Unique value counts per categorical column
-- -------------------------------------------------------------
SELECT
    COUNT(DISTINCT region_name)    AS unique_regions,
    COUNT(DISTINCT category)       AS unique_categories,
    COUNT(DISTINCT customer_id)    AS unique_customers,
    COUNT(DISTINCT sales_channel)  AS unique_channels,
    COUNT(DISTINCT payment_method) AS unique_payments
FROM sales_fact;

-- -------------------------------------------------------------
-- 6. Transactions per region
-- -------------------------------------------------------------
SELECT
    region_name,
    COUNT(*)                          AS transaction_count,
    ROUND(COUNT(*)::NUMERIC / (SELECT COUNT(*) FROM sales_fact) * 100, 2) AS pct_share
FROM sales_fact
GROUP BY region_name
ORDER BY transaction_count DESC;

-- -------------------------------------------------------------
-- 7. Transactions per category
-- -------------------------------------------------------------
SELECT
    category,
    COUNT(*)  AS transaction_count,
    ROUND(AVG(unit_price), 2) AS avg_unit_price,
    ROUND(AVG(total_revenue), 2) AS avg_order_value
FROM sales_fact
GROUP BY category
ORDER BY transaction_count DESC;

-- -------------------------------------------------------------
-- 8. Transactions per year
-- -------------------------------------------------------------
SELECT
    EXTRACT(YEAR FROM date_key)::INT AS year,
    COUNT(*)                         AS transactions,
    ROUND(SUM(total_revenue), 2)     AS total_revenue,
    ROUND(AVG(total_revenue), 2)     AS avg_order_value
FROM sales_fact
GROUP BY year
ORDER BY year;

-- -------------------------------------------------------------
-- 9. Sales channel distribution
-- -------------------------------------------------------------
SELECT
    sales_channel,
    COUNT(*)                      AS transactions,
    ROUND(SUM(total_revenue), 2)  AS revenue,
    ROUND(AVG(total_revenue), 2)  AS avg_order_value
FROM sales_fact
GROUP BY sales_channel
ORDER BY revenue DESC;

-- -------------------------------------------------------------
-- 10. Payment method distribution
-- -------------------------------------------------------------
SELECT
    payment_method,
    COUNT(*)                      AS transactions,
    ROUND(SUM(total_revenue), 2)  AS revenue,
    ROUND(AVG(total_revenue), 2)  AS avg_order_value
FROM sales_fact
GROUP BY payment_method
ORDER BY transactions DESC;

-- -------------------------------------------------------------
-- 11. Quantity distribution
-- -------------------------------------------------------------
SELECT
    quantity,
    COUNT(*)  AS transactions,
    ROUND(COUNT(*)::NUMERIC / (SELECT COUNT(*) FROM sales_fact) * 100, 2) AS pct_share
FROM sales_fact
GROUP BY quantity
ORDER BY quantity;

-- -------------------------------------------------------------
-- 12. Basic numeric summary statistics
-- -------------------------------------------------------------
SELECT
    ROUND(MIN(unit_price), 2)       AS min_unit_price,
    ROUND(MAX(unit_price), 2)       AS max_unit_price,
    ROUND(AVG(unit_price), 2)       AS avg_unit_price,

    ROUND(MIN(total_revenue), 2)    AS min_revenue,
    ROUND(MAX(total_revenue), 2)    AS max_revenue,
    ROUND(AVG(total_revenue), 2)    AS avg_revenue,
    ROUND(SUM(total_revenue), 2)    AS total_revenue,

    ROUND(MIN(profit), 2)           AS min_profit,
    ROUND(MAX(profit), 2)           AS max_profit,
    ROUND(AVG(profit), 2)           AS avg_profit,
    ROUND(SUM(profit), 2)           AS total_profit,

    ROUND(AVG(profit_margin_pct), 2) AS avg_margin_pct
FROM sales_fact;
-- =============================================================
