-- =============================================================
-- 01_schema_setup.sql
-- Sales Performance & Revenue Analysis - Database Schema
-- Star Schema Design: Fact + Dimension Tables
-- =============================================================

-- -------------------------------------------------------------
-- DROP EXISTING TABLES (if re-running)
-- -------------------------------------------------------------
DROP TABLE IF EXISTS sales_fact CASCADE;
DROP TABLE IF EXISTS time_dim CASCADE;
DROP TABLE IF EXISTS region_dim CASCADE;
DROP TABLE IF EXISTS product_dim CASCADE;
DROP TABLE IF EXISTS customer_dim CASCADE;

-- -------------------------------------------------------------
-- DIMENSION TABLE: time_dim
-- -------------------------------------------------------------
CREATE TABLE time_dim (
    date_key        DATE PRIMARY KEY,
    year            INT NOT NULL,
    quarter         INT NOT NULL,
    quarter_label   VARCHAR(2) NOT NULL,   -- 'Q1','Q2','Q3','Q4'
    month_num       INT NOT NULL,
    month_name      VARCHAR(12) NOT NULL,
    day             INT NOT NULL,
    day_of_week     VARCHAR(10) NOT NULL,
    is_weekend      BOOLEAN NOT NULL DEFAULT FALSE
);

-- -------------------------------------------------------------
-- DIMENSION TABLE: region_dim
-- -------------------------------------------------------------
CREATE TABLE region_dim (
    region_id       SERIAL PRIMARY KEY,
    region_name     VARCHAR(20) NOT NULL UNIQUE,
    region_manager  VARCHAR(50),
    annual_target   NUMERIC(12,2)          -- yearly revenue target
);

-- -------------------------------------------------------------
-- DIMENSION TABLE: product_dim
-- -------------------------------------------------------------
CREATE TABLE product_dim (
    product_id      SERIAL PRIMARY KEY,
    category        VARCHAR(50) NOT NULL,
    product_name    VARCHAR(100) NOT NULL,
    base_price      NUMERIC(10,2) NOT NULL,
    profit_margin   NUMERIC(5,2) NOT NULL  -- e.g. 35.00 = 35%
);

-- -------------------------------------------------------------
-- DIMENSION TABLE: customer_dim
-- -------------------------------------------------------------
CREATE TABLE customer_dim (
    customer_id     VARCHAR(12) PRIMARY KEY,
    segment         VARCHAR(20),           -- Gold / Silver / Bronze
    first_purchase  DATE,
    region          VARCHAR(20)
);

-- -------------------------------------------------------------
-- FACT TABLE: sales_fact
-- Central table that references all dimensions
-- -------------------------------------------------------------
CREATE TABLE sales_fact (
    transaction_id      VARCHAR(12) PRIMARY KEY,
    date_key            DATE        NOT NULL REFERENCES time_dim(date_key),
    region_name         VARCHAR(20) NOT NULL REFERENCES region_dim(region_name),
    category            VARCHAR(50) NOT NULL,
    product_name        VARCHAR(100) NOT NULL,
    customer_id         VARCHAR(12) NOT NULL,
    quantity            INT         NOT NULL CHECK (quantity BETWEEN 1 AND 100),
    unit_price          NUMERIC(10,2) NOT NULL,
    total_revenue       NUMERIC(12,2) NOT NULL,
    cost_per_unit       NUMERIC(10,2) NOT NULL,
    total_cost          NUMERIC(12,2) NOT NULL,
    profit              NUMERIC(12,2) NOT NULL,
    profit_margin_pct   NUMERIC(6,2) NOT NULL,
    sales_channel       VARCHAR(20) NOT NULL,
    payment_method      VARCHAR(20) NOT NULL,
    quarterly_target_k  INT         NOT NULL  -- target in $000s
);

-- -------------------------------------------------------------
-- INDEXES (performance optimization)
-- -------------------------------------------------------------
CREATE INDEX idx_fact_date        ON sales_fact(date_key);
CREATE INDEX idx_fact_region      ON sales_fact(region_name);
CREATE INDEX idx_fact_category    ON sales_fact(category);
CREATE INDEX idx_fact_customer    ON sales_fact(customer_id);
CREATE INDEX idx_fact_channel     ON sales_fact(sales_channel);
CREATE INDEX idx_fact_year_region ON sales_fact(date_key, region_name);

-- -------------------------------------------------------------
-- SEED DATA: region_dim
-- -------------------------------------------------------------
INSERT INTO region_dim (region_name, region_manager, annual_target) VALUES
('North',   'Sarah Mitchell',  5200000.00),
('South',   'James Rodriguez', 4500000.00),
('East',    'Emily Chen',      4000000.00),
('West',    'David Kumar',     3800000.00),
('Central', 'Laura Williams',  3500000.00);

-- -------------------------------------------------------------
-- NOTES
-- -------------------------------------------------------------
-- • time_dim rows should be populated for every date in range (2022-01-01 to 2024-12-31)
-- • sales_fact rows are loaded from the generated Excel dataset
-- • customer_dim is derived from sales_fact (GROUP BY customer_id)
-- • product_dim categories map 1:1 to the 10 categories in the dataset
-- =============================================================
