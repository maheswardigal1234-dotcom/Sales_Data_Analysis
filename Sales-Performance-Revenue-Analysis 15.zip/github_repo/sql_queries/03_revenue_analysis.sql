-- =============================================================
-- 03_revenue_analysis.sql
-- Revenue trends: monthly, quarterly, yearly, and cumulative
-- =============================================================

-- -------------------------------------------------------------
-- 1. Total revenue by year
-- -------------------------------------------------------------
SELECT
    EXTRACT(YEAR FROM date_key)::INT AS year,
    ROUND(SUM(total_revenue), 2)     AS total_revenue,
    ROUND(SUM(profit), 2)            AS total_profit,
    ROUND(AVG(total_revenue), 2)     AS avg_order_value,
    COUNT(*)                         AS transactions
FROM sales_fact
GROUP BY year
ORDER BY year;

-- -------------------------------------------------------------
-- 2. Monthly revenue trend (all years)
-- -------------------------------------------------------------
SELECT
    EXTRACT(YEAR  FROM date_key)::INT AS year,
    EXTRACT(MONTH FROM date_key)::INT AS month,
    ROUND(SUM(total_revenue), 2)      AS revenue,
    COUNT(*)                          AS transactions,
    ROUND(AVG(total_revenue), 2)      AS avg_order_value
FROM sales_fact
GROUP BY year, month
ORDER BY year, month;

-- -------------------------------------------------------------
-- 3. Quarterly revenue (all years)
-- -------------------------------------------------------------
SELECT
    EXTRACT(YEAR FROM date_key)::INT                          AS year,
    EXTRACT(QUARTER FROM date_key)::INT                       AS quarter,
    'Q' || EXTRACT(QUARTER FROM date_key)::INT                AS quarter_label,
    ROUND(SUM(total_revenue), 2)                              AS revenue,
    ROUND(SUM(profit), 2)                                     AS profit,
    COUNT(*)                                                  AS transactions,
    ROUND(AVG(total_revenue), 2)                              AS avg_order_value,
    MIN(quarterly_target_k) * 1000                            AS target_revenue
FROM sales_fact
GROUP BY year, quarter
ORDER BY year, quarter;

-- -------------------------------------------------------------
-- 4. Target vs Actual (quarterly)
-- -------------------------------------------------------------
WITH quarterly AS (
    SELECT
        EXTRACT(YEAR FROM date_key)::INT    AS year,
        EXTRACT(QUARTER FROM date_key)::INT AS quarter,
        ROUND(SUM(total_revenue), 2)        AS actual_revenue,
        MIN(quarterly_target_k) * 1000      AS target_revenue
    FROM sales_fact
    GROUP BY year, quarter
)
SELECT
    year,
    'Q' || quarter                                                  AS quarter,
    actual_revenue,
    target_revenue,
    ROUND(actual_revenue - target_revenue, 2)                       AS variance,
    ROUND((actual_revenue - target_revenue) / target_revenue * 100, 2) AS variance_pct,
    CASE
        WHEN actual_revenue >= target_revenue THEN 'Above Target'
        WHEN actual_revenue >= target_revenue * 0.9 THEN 'Near Target'
        ELSE 'Below Target'
    END AS status
FROM quarterly
ORDER BY year, quarter;

-- -------------------------------------------------------------
-- 5. Year-over-Year revenue growth
-- -------------------------------------------------------------
WITH yearly_rev AS (
    SELECT
        EXTRACT(YEAR FROM date_key)::INT AS year,
        ROUND(SUM(total_revenue), 2)     AS revenue
    FROM sales_fact
    GROUP BY year
)
SELECT
    year,
    revenue,
    LAG(revenue) OVER (ORDER BY year)                                       AS prev_year_revenue,
    ROUND(revenue - LAG(revenue) OVER (ORDER BY year), 2)                   AS yoy_change,
    ROUND((revenue - LAG(revenue) OVER (ORDER BY year))
          / LAG(revenue) OVER (ORDER BY year) * 100, 2)                     AS yoy_growth_pct
FROM yearly_rev
ORDER BY year;

-- -------------------------------------------------------------
-- 6. Quarter-over-Quarter revenue growth
-- -------------------------------------------------------------
WITH quarterly_rev AS (
    SELECT
        EXTRACT(YEAR FROM date_key)::INT    AS year,
        EXTRACT(QUARTER FROM date_key)::INT AS quarter,
        ROUND(SUM(total_revenue), 2)        AS revenue
    FROM sales_fact
    GROUP BY year, quarter
    ORDER BY year, quarter
)
SELECT
    year,
    'Q' || quarter                                                              AS quarter,
    revenue,
    LAG(revenue) OVER (ORDER BY year, quarter)                                  AS prev_quarter_revenue,
    ROUND(revenue - LAG(revenue) OVER (ORDER BY year, quarter), 2)              AS qoq_change,
    ROUND((revenue - LAG(revenue) OVER (ORDER BY year, quarter))
          / LAG(revenue) OVER (ORDER BY year, quarter) * 100, 2)               AS qoq_growth_pct
FROM quarterly_rev
ORDER BY year, quarter;

-- -------------------------------------------------------------
-- 7. Running / cumulative revenue by month (2024)
-- -------------------------------------------------------------
WITH monthly_2024 AS (
    SELECT
        EXTRACT(MONTH FROM date_key)::INT AS month,
        ROUND(SUM(total_revenue), 2)      AS monthly_revenue
    FROM sales_fact
    WHERE EXTRACT(YEAR FROM date_key) = 2024
    GROUP BY month
    ORDER BY month
)
SELECT
    month,
    monthly_revenue,
    ROUND(SUM(monthly_revenue) OVER (ORDER BY month ROWS UNBOUNDED PRECEDING), 2) AS cumulative_revenue
FROM monthly_2024
ORDER BY month;

-- -------------------------------------------------------------
-- 8. Revenue contribution by sales channel per year
-- -------------------------------------------------------------
SELECT
    EXTRACT(YEAR FROM date_key)::INT AS year,
    sales_channel,
    ROUND(SUM(total_revenue), 2)     AS revenue,
    ROUND(
        SUM(total_revenue) * 100.0 /
        SUM(SUM(total_revenue)) OVER (PARTITION BY EXTRACT(YEAR FROM date_key)::INT), 2
    )                                AS channel_share_pct
FROM sales_fact
GROUP BY year, sales_channel
ORDER BY year, revenue DESC;

-- -------------------------------------------------------------
-- 9. Average order value trend (monthly, 2024)
-- -------------------------------------------------------------
SELECT
    EXTRACT(MONTH FROM date_key)::INT AS month,
    ROUND(AVG(total_revenue), 2)      AS avg_order_value,
    COUNT(*)                          AS transactions
FROM sales_fact
WHERE EXTRACT(YEAR FROM date_key) = 2024
GROUP BY month
ORDER BY month;

-- -------------------------------------------------------------
-- 10. Revenue vs profit margin by quarter (2024)
-- -------------------------------------------------------------
SELECT
    'Q' || EXTRACT(QUARTER FROM date_key)::INT  AS quarter,
    ROUND(SUM(total_revenue), 2)                AS revenue,
    ROUND(SUM(profit), 2)                       AS profit,
    ROUND(SUM(profit) / SUM(total_revenue) * 100, 2) AS effective_margin_pct
FROM sales_fact
WHERE EXTRACT(YEAR FROM date_key) = 2024
GROUP BY quarter
ORDER BY quarter;
-- =============================================================
