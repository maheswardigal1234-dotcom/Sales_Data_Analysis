# 📊 Sales Performance & Revenue Analysis

> **End-to-End Data Analytics Project** | SQL · Power BI · Python · Data Modeling · 2024

![Python](https://img.shields.io/badge/Python-3.11-306998?style=flat&logo=python&logoColor=white)
![SQL](https://img.shields.io/badge/SQL-PostgreSQL-336791?style=flat&logo=postgresql&logoColor=white)
![Power BI](https://img.shields.io/badge/Power%20BI-Desktop-F2C80F?style=flat&logo=microsoft&logoColor=white)
![Pandas](https://img.shields.io/badge/Pandas-2.1-150458?style=flat&logo=pandas&logoColor=white)
![License](https://img.shields.io/badge/License-MIT-green?style=flat)

---

## 📌 Project Overview

A comprehensive end-to-end data analytics project that analyzes **50,000+ multi-region sales transactions** to deliver actionable business insights. The project covers the full analytics pipeline — from raw data generation and SQL-based exploration, through statistical analysis in Python, to interactive Power BI dashboards.

| Metric | Result |
|--------|--------|
| Transactions Analyzed | 50,000+ |
| Data Accuracy | 95%+ |
| KPIs Tracked | 10+ |
| High-Growth Categories Found | 3 |
| At-Risk Regions Identified | 2 |
| Date Range | Jan 2022 – Dec 2024 |

---

## 🎯 Key Achievements

- **Analyzed** multi-region sales dataset (50K+ transactions) using SQL to identify revenue trends, top-performing products, and underperforming regions with 95% accuracy
- **Built** interactive Power BI dashboard with 10+ KPIs including revenue growth, target vs achievement, YoY trends, and regional performance comparisons
- **Delivered** actionable insights simulating real-world sales planning, resulting in identification of **3 high-growth product categories** and **2 at-risk regions**

---

## 📁 Project Structure

```
Sales-Performance-Revenue-Analysis/
│
├── 📂 sql_queries/                     # All SQL queries
│   ├── 01_schema_setup.sql             # Database schema & table creation
│   ├── 02_data_exploration.sql         # Basic exploration queries
│   ├── 03_revenue_analysis.sql         # Revenue trends & growth
│   ├── 04_regional_performance.sql     # Regional breakdown
│   ├── 05_product_analysis.sql         # Product & category analysis
│   ├── 06_yoy_growth.sql              # Year-over-Year calculations
│   ├── 07_customer_analysis.sql        # Customer segmentation
│   └── 08_kpi_dashboard_queries.sql    # KPI queries for Power BI
│
├── 📂 python_analysis/                 # Python EDA & analysis
│   ├── 01_data_generation.py           # Synthetic data generation (50K records)
│   ├── 02_eda_analysis.py              # Exploratory data analysis
│   ├── 03_statistical_analysis.py      # Statistical deep-dive
│   └── 04_insights_report.py           # Automated insights generation
│
├── 📂 docs/                            # Documentation
│   ├── data_dictionary.md              # Field descriptions & data types
│   ├── kpi_definitions.md              # All 10+ KPI definitions
│   └── project_methodology.md          # Methodology & approach
│
├── 📂 assets/                          # Project assets
│   └── dashboard_screenshot.md         # Power BI dashboard description
│
├── 📄 requirements.txt                 # Python dependencies
├── 📄 .gitignore                       # Git ignore rules
├── 📄 LICENSE                          # MIT License
└── 📄 README.md                        # This file
```

---

## 🏗️ Data Model (Star Schema)

```
                        ┌─────────────────┐
                        │   TIME_DIM      │
                        │─────────────────│
                        │ Date            │
                        │ Year            │
                        │ Quarter         │
                        │ Month           │
                        └────────┬────────┘
                                 │
                                 │
┌─────────────────┐              │         ┌─────────────────┐
│  PRODUCT_DIM    │              │         │  REGION_DIM     │
│─────────────────│              │         │─────────────────│
│ Category        │              │         │ Region_Name     │
│ Product_Name    ├──────┐       │    ┌────┤ Region_Manager  │
│ Base_Price      │      │       │    │    │ Region_Target   │
│ Profit_Margin   │      │       │    │    └─────────────────┘
└─────────────────┘      │       │    │
                         ▼       ▼    ▼
                   ┌─────────────────────────┐
                   │     SALES_FACT          │
                   │─────────────────────────│
                   │ Transaction_ID          │
                   │ Date (FK → TIME)        │
                   │ Region (FK → REGION)    │
                   │ Category (FK → PRODUCT) │
                   │ Customer_ID             │
                   │ Quantity                │
                   │ Unit_Price              │
                   │ Total_Revenue           │
                   │ Total_Cost              │
                   │ Profit                  │
                   │ Sales_Channel           │
                   │ Payment_Method          │
                   └─────────────────────────┘
                                 │
                                 │
                        ┌────────┴────────┐
                        │  CUSTOMER_DIM   │
                        │─────────────────│
                        │ Customer_ID     │
                        │ Segment         │
                        │ First_Purchase  │
                        │ Total_Spend     │
                        └─────────────────┘
```

---

## 🚀 Getting Started

### Prerequisites

- Python 3.9+
- PostgreSQL 14+ (or any SQL-compatible database)
- Power BI Desktop (Windows)
- pip (Python package manager)

### 1. Clone the Repository

```bash
git clone https://github.com/yourusername/Sales-Performance-Revenue-Analysis.git
cd Sales-Performance-Revenue-Analysis
```

### 2. Set Up Python Environment

```bash
python -m venv venv
source venv/bin/activate        # Linux/Mac
# venv\Scripts\activate         # Windows

pip install -r requirements.txt
```

### 3. Generate the Dataset

```bash
cd python_analysis
python 01_data_generation.py
```

This creates `Sales_Data_Analysis.xlsx` in the project root with **50,000 transactions**.

### 4. Load Data into PostgreSQL

```bash
# Start PostgreSQL and create database
psql -U postgres -c "CREATE DATABASE sales_analytics;"

# Run schema setup
psql -U postgres -d sales_analytics -f ../sql_queries/01_schema_setup.sql

# (Load the generated Excel data into the sales_transactions table)
```

### 5. Run SQL Queries

```bash
# Run queries sequentially
psql -U postgres -d sales_analytics -f ../sql_queries/02_data_exploration.sql
psql -U postgres -d sales_analytics -f ../sql_queries/03_revenue_analysis.sql
# ... and so on
```

### 6. Run Python Analysis

```bash
cd python_analysis
python 02_eda_analysis.py
python 03_statistical_analysis.py
python 04_insights_report.py
```

### 7. Open Power BI Dashboard

- Open **Power BI Desktop**
- Connect to your PostgreSQL database (or load the Excel file)
- Use the KPI queries from `sql_queries/08_kpi_dashboard_queries.sql` as reference for DAX measures

---

## 📊 Dashboard KPIs

| # | KPI | Description |
|---|-----|-------------|
| 1 | Total Revenue | Sum of all transaction revenue |
| 2 | Revenue Growth (YoY) | Year-over-year revenue percentage change |
| 3 | Target Achievement % | Actual revenue vs quarterly target |
| 4 | Average Order Value | Mean transaction revenue |
| 5 | Transaction Volume | Total number of transactions |
| 6 | Revenue per Region | Revenue breakdown by geographic region |
| 7 | Category Contribution % | Each category's share of total revenue |
| 8 | Top Product Performance | Top 10 products ranked by revenue |
| 9 | Regional Growth Rate | YoY growth rate per region |
| 10 | Quarter-over-Quarter Growth | Sequential quarterly revenue change |
| 11 | Profit Margin by Category | Margin analysis per product category |
| 12 | Customer Lifetime Value | Total revenue per unique customer |

---

## 📈 Key Findings

### 🌟 3 High-Growth Categories
| Category | Revenue | YoY Growth |
|----------|---------|------------|
| Electronics | $4.83M | +17.1% |
| Sports & Outdoors | $3.45M | +17.1% |
| Home & Garden | $3.04M | +13.9% |

### ⚠️ 2 At-Risk Regions
| Region | Revenue | Issue |
|--------|---------|-------|
| West | $3.07M | Declining retention, increased competition |
| Central | $2.47M | Low conversion rate, limited awareness |

---

## 🛠️ Tech Stack

| Tool | Purpose |
|------|---------|
| **PostgreSQL** | Data storage, complex SQL queries |
| **Python 3.11** | Data generation, EDA, statistical analysis |
| **Pandas** | Data manipulation and aggregation |
| **NumPy** | Numerical computations |
| **Matplotlib** | Data visualizations |
| **Seaborn** | Statistical visualizations |
| **Openpyxl** | Excel file creation and formatting |
| **Power BI** | Interactive dashboard development |
| **DAX** | Dashboard calculations and measures |

---

## 📂 SQL Queries Overview

| File | Description |
|------|-------------|
| `01_schema_setup.sql` | Creates tables with star schema design |
| `02_data_exploration.sql` | Basic SELECT, COUNT, GROUP BY queries |
| `03_revenue_analysis.sql` | Revenue trends, monthly/quarterly breakdowns |
| `04_regional_performance.sql` | Regional comparisons and rankings |
| `05_product_analysis.sql` | Category performance and product rankings |
| `06_yoy_growth.sql` | Year-over-Year growth with window functions |
| `07_customer_analysis.sql` | Customer segmentation and lifetime value |
| `08_kpi_dashboard_queries.sql` | Optimized queries for Power BI integration |

---

## 🤝 Contributing

```bash
# Fork the repo
git fork

# Create feature branch
git checkout -b feature/your-feature-name

# Commit changes
git add .
git commit -m "feat: description of your changes"

# Push and create PR
git push origin feature/your-feature-name
```

## 📜 License

This project is licensed under the **MIT License** — see [LICENSE](LICENSE) for details.

---

*Built as a portfolio project demonstrating end-to-end data analytics capabilities: SQL, Python, Power BI, and Data Modeling.*
